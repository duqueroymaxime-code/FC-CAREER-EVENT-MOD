﻿"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "fifa-career-overhaul-media-hub-v16";
const BUILD_LABEL = "MEDIA_HUB_V16_ACTIVE";
const FORCE_TRANSFER_OFFERS = true;
const DEFAULT_THEME = "dark";
const DEFAULT_SCREEN = "home";
const DEFAULT_TAB = "dashboard";
const DEFAULT_TYPE = "manager";
const EVENT_MEMORY_LIMIT = 12;

const UI_GRADIENTS = {
  panel: "linear-gradient(180deg, rgba(15,23,42,.92), rgba(15,23,42,.72))",
  glass: "rgba(15,23,42,.58)",
};

const CLUBS = [
  {
    name: "Girondins de Bordeaux",
    league: "National 2",
    budget: 4,
    reputation: 67,
    objectives: "Remontée sportive et reconstruction du statut pro",
    colors: ["#001b44", "#7f1734"],
  },
  {
    name: "Paris Saint-Germain",
    league: "Ligue 1",
    budget: 180,
    reputation: 93,
    objectives: "Titre national et parcours européen",
    colors: ["#001f5b", "#e30613"],
  },
  {
    name: "Olympique de Marseille",
    league: "Ligue 1",
    budget: 72,
    reputation: 82,
    objectives: "Top 4 et identité forte",
    colors: ["#0ea5e9", "#ffffff"],
  },
  {
    name: "Arsenal",
    league: "Premier League",
    budget: 130,
    reputation: 89,
    objectives: "Jouer le titre et développer les jeunes",
    colors: ["#dc2626", "#ffffff"],
  },
];

const LEAGUE_PRESETS = {
  "Ligue 1": [
    { name: "Paris Saint-Germain", strength: 91 },
    { name: "Olympique de Marseille", strength: 82 },
    { name: "AS Monaco", strength: 80 },
    { name: "Olympique Lyonnais", strength: 78 },
    { name: "LOSC Lille", strength: 77 },
    { name: "RC Lens", strength: 76 },
    { name: "Stade Rennais", strength: 75 },
    { name: "OGC Nice", strength: 75 },
    { name: "Toulouse FC", strength: 70 },
    { name: "FC Nantes", strength: 69 },
    { name: "Montpellier HSC", strength: 68 },
    { name: "RC Strasbourg", strength: 68 },
    { name: "Stade Brestois", strength: 68 },
    { name: "AJ Auxerre", strength: 66 },
    { name: "Angers SCO", strength: 64 },
    { name: "Le Havre AC", strength: 64 },
  ],

  "Premier League": [
    { name: "Manchester City", strength: 91 },
    { name: "Arsenal", strength: 89 },
    { name: "Liverpool", strength: 88 },
    { name: "Chelsea", strength: 84 },
    { name: "Manchester United", strength: 82 },
    { name: "Tottenham Hotspur", strength: 81 },
    { name: "Newcastle United", strength: 80 },
    { name: "Aston Villa", strength: 79 },
    { name: "Brighton", strength: 76 },
    { name: "West Ham United", strength: 75 },
    { name: "Crystal Palace", strength: 73 },
    { name: "Fulham", strength: 72 },
    { name: "Everton", strength: 71 },
    { name: "Brentford", strength: 71 },
    { name: "Wolverhampton", strength: 70 },
    { name: "Nottingham Forest", strength: 69 },
  ],

  "National 2": [
    { name: "Girondins de Bordeaux", strength: 67 },
    { name: "Les Herbiers VF", strength: 61 },
    { name: "Saumur OFC", strength: 58 },
    { name: "Stade Poitevin", strength: 57 },
    { name: "Blois Foot 41", strength: 56 },
    { name: "Bergerac Périgord FC", strength: 59 },
    { name: "Angoulême CFC", strength: 58 },
    { name: "Trélissac FC", strength: 56 },
    { name: "Romorantin", strength: 55 },
    { name: "Bourges Foot 18", strength: 57 },
    { name: "La Roche VF", strength: 56 },
    { name: "Saint-Pryvé Saint-Hilaire", strength: 56 },
    { name: "GOAL FC", strength: 60 },
    { name: "Andrézieux-Bouthéon", strength: 57 },
    { name: "Hyères FC", strength: 58 },
    { name: "Fréjus Saint-Raphaël", strength: 57 },
  ],
};

const SQUAD_PRESETS = {
  "Paris Saint-Germain": [
    ["Gianluigi Donnarumma", "GB", 26, 87],
    ["Achraf Hakimi", "DD", 27, 84],
    ["Marquinhos", "DC", 32, 85],
    ["Nuno Mendes", "DG", 24, 84],
    ["Vitinha", "MC", 26, 85],
    ["Warren Zaïre-Emery", "MC", 20, 82],
    ["Ousmane Dembélé", "AD", 29, 86],
    ["Bradley Barcola", "AG", 24, 83],
    ["Gonçalo Ramos", "BU", 25, 82],
  ],

  "Olympique de Marseille": [
    ["Pau López", "GB", 31, 79],
    ["Leonardo Balerdi", "DC", 27, 79],
    ["Quentin Merlin", "DG", 24, 77],
    ["Geoffrey Kondogbia", "MDC", 33, 78],
    ["Amine Harit", "MOC", 29, 78],
    ["Pierre-Emerick Aubameyang", "BU", 37, 81],
    ["Iliman Ndiaye", "AD", 26, 78],
  ],

  Arsenal: [
    ["David Raya", "GB", 30, 83],
    ["William Saliba", "DC", 25, 87],
    ["Gabriel Magalhães", "DC", 28, 85],
    ["Ben White", "DD", 28, 82],
    ["Declan Rice", "MDC", 27, 87],
    ["Martin Ødegaard", "MOC", 27, 88],
    ["Bukayo Saka", "AD", 24, 89],
    ["Gabriel Martinelli", "AG", 25, 84],
    ["Kai Havertz", "BU", 27, 83],
  ],

  "Girondins de Bordeaux": [
    ["Lassana Diabaté", "GB", 28, 66],
    ["Jean Grillot", "DC", 22, 61],
    ["Adrien Louveau", "DC", 25, 62],
  ],
};

const MONTHS = [
  "Août",
  "Septembre",
  "Octobre",
  "Novembre",
  "Décembre",
  "Janvier",
  "Février",
  "Mars",
  "Avril",
  "Mai",
];
const POSITIONS = [
  "GB",
  "DD",
  "DC",
  "DG",
  "MDC",
  "MC",
  "MOC",
  "AD",
  "AG",
  "BU",
];
const FIRST_NAMES = [
  "Nino",
  "Enzo",
  "Noah",
  "Ilyes",
  "Lucas",
  "Hugo",
  "Adam",
  "Yanis",
  "Rayan",
  "Nathan",
];
const LAST_NAMES = [
  "Bernard",
  "Garcia",
  "Durand",
  "Morel",
  "Martin",
  "Dubois",
  "Lefèvre",
  "Silva",
  "Diallo",
  "Traoré",
];

const PLAYER_PRESETS = {
  "Paris Saint-Germain": [
    { name: "Kylian Mbappé", position: "BU", overall: 92 },
    { name: "Neymar Jr", position: "MOC", overall: 90 },
    { name: "Achraf Hakimi", position: "DD", overall: 86 },
    { name: "Marquinhos", position: "DC", overall: 85 },
    { name: "Marco Verratti", position: "MC", overall: 85 },
    { name: "Gianluigi Donnarumma", position: "GB", overall: 88 },
    { name: "Presnel Kimpembe", position: "DC", overall: 84 },
    { name: "Hugo Ekitiké", position: "BU", overall: 82 },
    { name: "Carlos Soler", position: "MC", overall: 83 },
    { name: "Warren Zaire-Emery", position: "MDC", overall: 80 },
  ],
  "Olympique de Marseille": [
    { name: "Dimitri Payet", position: "MOC", overall: 84 },
    { name: "Matteo Guendouzi", position: "MDC", overall: 82 },
    { name: "William Saliba", position: "DC", overall: 85 },
    { name: "Pierre-Emerick Aubameyang", position: "BU", overall: 83 },
    { name: "Konrad de la Fuente", position: "AG", overall: 78 },
    { name: "Pape Gueye", position: "MDC", overall: 78 },
    { name: "Gerson", position: "MC", overall: 80 },
    { name: "Pol Lirola", position: "DG", overall: 79 },
    { name: "Steve Mandanda", position: "GB", overall: 79 },
    { name: "Luis Henrique", position: "AD", overall: 76 },
  ],
  Arsenal: [
    { name: "Bukayo Saka", position: "AD", overall: 88 },
    { name: "Gabriel Martinelli", position: "AG", overall: 85 },
    { name: "Martin Ødegaard", position: "MOC", overall: 86 },
    { name: "William Saliba", position: "DC", overall: 85 },
    { name: "Oleksandr Zinchenko", position: "DG", overall: 83 },
    { name: "Gabriel Jesus", position: "BU", overall: 84 },
    { name: "Thomas Partey", position: "MDC", overall: 82 },
    { name: "Ben White", position: "DC", overall: 82 },
    { name: "Aaron Ramsdale", position: "GB", overall: 83 },
    { name: "Jorginho", position: "MC", overall: 80 },
  ],
  "Girondins de Bordeaux": [
    { name: "Calvin Ramsay", position: "DD", overall: 74 },
    { name: "Jules Koundé", position: "DC", overall: 83 },
    { name: "Hwang Ui-jo", position: "BU", overall: 79 },
    { name: "M’Baye Niang", position: "BU", overall: 75 },
    { name: "Yacine Adli", position: "MOC", overall: 77 },
    { name: "Loris Benito", position: "DG", overall: 74 },
    { name: "Nicolas De Préville", position: "AD", overall: 73 },
    { name: "Enzo Crivelli", position: "BU", overall: 76 },
    { name: "Toma Basic", position: "MC", overall: 74 },
    { name: "Thomas Touré", position: "AG", overall: 73 },
  ],
};

function createSquadForClub(club) {
  const preset = SQUAD_PRESETS[club.name];

  if (!preset) {
    return Array.from({ length: 22 }, (_, index) =>
      createPlayer(index, club.name),
    );
  }

  const presetPlayers = preset.map((player) =>
    createPresetPlayer(player, club.name),
  );

  const generatedPlayers = Array.from(
    { length: Math.max(0, 22 - presetPlayers.length) },
    (_, index) => createPlayer(index, club.name),
  );

  return [...presetPlayers, ...generatedPlayers].map((player) =>
    withContract(player, club.budget),
  );
}

const INJURY_TYPES = [
  {
    label: "Entorse légère",
    severity: "modérée",
    minWeeks: 2,
    maxWeeks: 3,
    formPenalty: 6,
  },
  {
    label: "Douleur musculaire",
    severity: "légère",
    minWeeks: 1,
    maxWeeks: 2,
    formPenalty: 4,
  },
  {
    label: "Élongation",
    severity: "sérieuse",
    minWeeks: 3,
    maxWeeks: 5,
    formPenalty: 9,
  },
  {
    label: "Blessure aux ischios",
    severity: "sérieuse",
    minWeeks: 4,
    maxWeeks: 7,
    formPenalty: 12,
  },
  {
    label: "Lésion ligamentaire",
    severity: "grave",
    minWeeks: 8,
    maxWeeks: 12,
    formPenalty: 18,
  },
];

const TRANSFER_WINDOWS = [
  { startWeek: 1, endWeek: 4, label: "Mercato estival" },
  { startWeek: 6, endWeek: 8, label: "Mercato hivernal" },
];

const BUYER_CLUBS = [
  { name: "AS Monaco", strength: 80 },
  { name: "RC Lens", strength: 76 },
  { name: "Stade Rennais", strength: 75 },
  { name: "OGC Nice", strength: 75 },
  { name: "Manchester United", strength: 82 },
  { name: "Newcastle United", strength: 80 },
  { name: "Aston Villa", strength: 79 },
  { name: "Borussia Dortmund", strength: 82 },
  { name: "AC Milan", strength: 83 },
  { name: "Atlético de Madrid", strength: 86 },
];

const MARKET_PLAYER_POOL = [
  ["Lucas Chevalier", "GB", 24, 82, 38],
  ["Guillaume Restes", "GB", 21, 78, 22],
  ["Castello Lukeba", "DC", 23, 82, 42],
  ["Jean-Clair Todibo", "DC", 26, 81, 34],
  ["Maxence Lacroix", "DC", 26, 79, 24],
  ["Quentin Merlin", "DG", 24, 77, 16],
  ["Rayan Aït-Nouri", "DG", 25, 80, 32],
  ["Malo Gusto", "DD", 23, 80, 30],
  ["Khephren Thuram", "MC", 25, 80, 31],
  ["Manu Koné", "MC", 25, 79, 27],
  ["Enzo Le Fée", "MC", 26, 78, 22],
  ["Désiré Doué", "MOC", 21, 81, 46],
  ["Rayan Cherki", "MOC", 23, 80, 34],
  ["Maghnes Akliouche", "MOC", 24, 79, 29],
  ["Johan Bakayoko", "AD", 23, 81, 40],
  ["Edon Zhegrova", "AD", 27, 80, 28],
  ["Karim Adeyemi", "AG", 24, 82, 45],
  ["Georges Mikautadze", "BU", 25, 79, 26],
  ["Elye Wahi", "BU", 23, 78, 24],
  ["Jonathan David", "BU", 26, 83, 48],
];

const LOW_BUDGET_MARKET_POOL = [
  ["Mathis Picouleau", "MC", 25, 66, 1.2],
  ["Amadou Konaté", "BU", 23, 68, 1.8],
  ["Noah Raveyre", "GB", 21, 65, 0.9],
  ["Ilyes Hamache", "AG", 23, 67, 1.4],
  ["Tidiane Keita", "MDC", 27, 67, 1.1],
  ["Mamadou Camara", "DC", 24, 66, 1.3],
  ["Yanis Begraoui", "BU", 24, 69, 2.2],
  ["Tom Ducrocq", "MC", 26, 68, 1.7],
  ["Lenny Nangis", "AD", 31, 66, 0.8],
  ["Alexandre Mendy", "BU", 32, 70, 1.6],
];

const CONTRACT_STATUS = {
  SECURE: "stable",
  EXPIRING: "expiring",
  CRITICAL: "critical",
};

const BOARD_OBJECTIVE_TYPES = {
  LEAGUE_POSITION: "league_position",
  MORALE: "morale",
  FINANCES: "finances",
  DEVELOPMENT: "development",
  CLEAN_SHEET: "clean_sheet",
  UNBEATEN_RUN: "unbeaten_run",
};

const ACADEMY_COUNTRIES = [
  "France",
  "Angleterre",
  "Espagne",
  "Portugal",
  "Belgique",
  "Sénégal",
  "Côte d’Ivoire",
  "Brésil",
  "Argentine",
];

const ACADEMY_ARCHETYPES = [
  { label: "Gardien réflexe", positions: ["GB"], minOverall: 48, maxOverall: 62, minPotential: 70, maxPotential: 90 },
  { label: "Défenseur rugueux", positions: ["DC", "DD", "DG"], minOverall: 48, maxOverall: 64, minPotential: 68, maxPotential: 88 },
  { label: "Milieu technique", positions: ["MC", "MOC", "MDC"], minOverall: 50, maxOverall: 65, minPotential: 70, maxPotential: 91 },
  { label: "Ailier explosif", positions: ["AD", "AG"], minOverall: 49, maxOverall: 66, minPotential: 72, maxPotential: 92 },
  { label: "Buteur prometteur", positions: ["BU"], minOverall: 50, maxOverall: 66, minPotential: 70, maxPotential: 90 },
];

const CATEGORY_META = {
  Match: { icon: "⚽", color: "linear-gradient(90deg,#bef264,#22d3ee)" },
  Moral: { icon: "🧠", color: "linear-gradient(90deg,#38bdf8,#22d3ee)" },
  Vestiaire: { icon: "👥", color: "linear-gradient(90deg,#c084fc,#f0abfc)" },
  Médias: { icon: "📰", color: "linear-gradient(90deg,#facc15,#fb923c)" },
  Mercato: { icon: "✍️", color: "linear-gradient(90deg,#60a5fa,#818cf8)" },
  Blessures: { icon: "🏥", color: "linear-gradient(90deg,#fb7185,#f97316)" },
  Supporters: { icon: "🔥", color: "linear-gradient(90deg,#fb7185,#f43f5e)" },
  Direction: { icon: "🏛️", color: "linear-gradient(90deg,#e2e8f0,#94a3b8)" },
  Staff: { icon: "📊", color: "linear-gradient(90deg,#a78bfa,#60a5fa)" },
};

const MEDIA_SENTIMENTS = {
  POSITIVE: "positive",
  NEUTRAL: "neutral",
  NEGATIVE: "negative",
  VIRAL: "viral",
};

const PRESS_QUESTION_TYPES = {
  RESULT: "result",
  PLAYER: "player",
  BOARD: "board",
  TRANSFER: "transfer",
  INJURY: "injury",
  TACTICS: "tactics",
};

const SOCIAL_AUTHORS = [
  "FC Daily",
  "Tribune Locale",
  "CareerMode News",
  "Inside Football",
  "Ultra Zone",
  "DataFoot",
  "Le Vestiaire",
  "Fans Talk",
];

const FAN_REACTIONS = [
  "On veut plus d’ambition.",
  "Le projet commence à prendre forme.",
  "Il faut faire confiance aux jeunes.",
  "Le coach doit assumer ses choix.",
  "Ce joueur mérite plus de temps de jeu.",
  "La direction doit soutenir le projet.",
  "Le mercato peut tout changer.",
  "La dynamique est encourageante.",
];

const EVENT_TEMPLATES = {
  Match: [
    {
      type: "direct",
      title: "est dans une situation délicate",
      trigger: "situation critique",
      hook: "Un joueur se retrouve au cœur d’une situation sensible et demande ton intervention.",
      story:
        "Après le match, tout le vestiaire attend ta décision sur sa place dans le projet.",
      choices: ["Le soutenir", "Le recadrer", "L’isoler", "Parler à la presse"],
    },
    {
      type: "media",
      title: "est annoncé mécontent par les journalistes",
      trigger: "rumeur de vestiaire",
      hook: "La presse affirme que le joueur ne comprend plus ton projet sportif.",
      story:
        "Les commentaires s’emballent, et il faut gérer l’image du club tout en calmant le groupe.",
      choices: [
        "Répondre calmement",
        "Attaquer les médias",
        "Parler au joueur",
        "Laisser passer",
      ],
    },
    {
      type: "performance",
      title: "a livré une prestation controversée",
      trigger: "analyse du match",
      hook: "Ses performances oscillent trop, et le staff se pose des questions.",
      story:
        "Entre les supporters et le rapport du coach, ta crédibilité est en jeu.",
      choices: [
        "Changer sa position",
        "Lui donner du temps",
        "Le blâmer publiquement",
        "Expliquer ton plan",
      ],
    },
  ],
  Mercato: [
    {
      type: "transfer",
      title: "demande officiellement à partir",
      trigger: "envie de transfert",
      hook: "Le joueur vient directement t’annoncer qu’il veut quitter le club.",
      story:
        "C’est un dossier délicat qui peut affecter le groupe et le budget du club.",
      choices: [
        "Refuser net",
        "Fixer un prix",
        "Le convaincre de rester",
        "Le placer sur la liste",
      ],
    },
    {
      type: "offer",
      title: "reçoit une proposition inattendue",
      trigger: "intérêt étranger",
      hook: "Un club puissant a placé une offre sur sa table.",
      story:
        "Tu dois choisir entre ambition personnelle du joueur et stabilité de l’équipe.",
      choices: [
        "Laisser partir",
        "Négocier plus haut",
        "Le rassurer",
        "Garder le dossier secret",
      ],
    },
  ],
  Blessures: [
    {
      type: "medical",
      title: "cache une gêne physique",
      trigger: "fatigue élevée",
      hook: "Le staff découvre qu’il joue avec une douleur depuis plusieurs jours.",
      story:
        "Chaque minute sur le terrain pourrait aggraver sa condition et coûter un résultat.",
      choices: [
        "Le mettre au repos",
        "Réduire sa charge",
        "Le laisser décider",
        "Forcer les examens",
      ],
    },
    {
      type: "rehab",
      title: "relance un protocole de récupération",
      trigger: "douleur persistante",
      hook: "Il refuse de ralentir alors que le kiné reste inquiet.",
      story:
        "Il faut trouver le bon équilibre entre récupération et continuité du groupe.",
      choices: [
        "Insister sur le repos",
        "Lui donner une séance adaptée",
        "Changer le planning",
        "Prendre le risque",
      ],
    },
  ],
  Moral: [
    {
      type: "direct",
      title: "vient demander une discussion privée",
      trigger: "moral instable",
      hook: "Le joueur te demande cinq minutes loin du groupe.",
      story:
        "Sa confiance vacille et il veut savoir si tu comptes encore sur lui.",
      choices: [
        "L’écouter calmement",
        "Lui promettre plus de temps de jeu",
        "Lui rappeler la concurrence",
        "Reporter la discussion",
      ],
    },
    {
      type: "ambition",
      title: "se sent désengagé du projet",
      trigger: "niveaux de motivation",
      hook: "Il doute du sens de sa place dans l’équipe.",
      story:
        "Si tu ne regagnes pas sa confiance, la dynamique du vestiaire peut se briser.",
      choices: [
        "Réaffirmer le plan",
        "Changer son rôle",
        "Le vendre",
        "L’encourager",
      ],
    },
  ],
  Vestiaire: [
    {
      type: "squad",
      title: "divise le vestiaire",
      trigger: "tension collective",
      hook: "Deux groupes commencent à se former autour de sa situation.",
      story:
        "La cohésion du groupe est menacée et tu dois trancher avant que cela explose.",
      choices: [
        "Organiser une réunion fermée",
        "Choisir un leader fort",
        "Écarter le problème",
        "Changer la hiérarchie",
      ],
    },
    {
      type: "leadership",
      title: "conteste le capitaine",
      trigger: "autorité remise en cause",
      hook: "Il ne supporte plus certaines décisions de son capitaine.",
      story:
        "Ce conflit intérieur peut coûter cher si tu ne le règle pas rapidement.",
      choices: [
        "Médiatiser la confiance",
        "Protéger le capitaine",
        "Rééquilibrer le groupe",
        "Punis les deux",
      ],
    },
  ],
  Médias: [
    {
      type: "media",
      title: "fait l’objet d’une fuite dans la presse",
      trigger: "info sortie du vestiaire",
      hook: "Une information interne arrive dans les médias.",
      story: "Le climat médiatique devient toxique et le club doit réagir.",
      choices: [
        "Démentir publiquement",
        "Protéger le joueur",
        "Chercher la fuite",
        "Assumer la situation",
      ],
    },
    {
      type: "reputation",
      title: "a une interview tendue",
      trigger: "sortie médiatique",
      hook: "Il lâche des phrases qui enflamment les réseaux.",
      story: "Ta réponse doit contenir la crise sans l’aggraver.",
      choices: [
        "Le recadrer",
        "L’interviewer en interne",
        "Le soutenir",
        "Ignorer",
      ],
    },
  ],
  Supporters: [
    {
      type: "fans",
      title: "devient le favori des supporters",
      trigger: "popularité tribunes",
      hook: "Les supporters réclament son nom et critiquent tes choix.",
      story: "La pression des tribunes peut devenir un levier ou un piège.",
      choices: [
        "Le titulariser",
        "Expliquer ton choix",
        "Utiliser l’engouement",
        "Ne pas céder",
      ],
    },
    {
      type: "protest",
      title: "subit une campagne de banderoles",
      trigger: "flamme populaire",
      hook: "Les supporters brandissent son nom dans le stade.",
      story: "L’ambiance devient un enjeu politique et sportif.",
      choices: [
        "Jouer le jeu",
        "Calmer les supporters",
        "Changer de discours",
        "Le préserver",
      ],
    },
  ],
  Direction: [
    {
      type: "board",
      title: "devient un dossier surveillé par la direction",
      trigger: "enjeu financier",
      hook: "Le board veut savoir s'il fait encore partie du projet.",
      story: "Ta relation avec la direction est testée sur ce joueur.",
      choices: [
        "Le défendre",
        "Préparer une vente",
        "Demander du temps",
        "Le valoriser sportivement",
      ],
    },
    {
      type: "contract",
      title: "voit son contrat devenir un sujet de débat",
      trigger: "renouvellement proche",
      hook: "La direction surveille son rendement avant de trancher.",
      story:
        "Il représente un enjeu financier et un message pour le reste de l’effectif.",
      choices: [
        "Lui proposer une extension",
        "Le vendre",
        "Le faire patienter",
        "Relâcher la pression",
      ],
    },
  ],
  Staff: [
    {
      type: "staff",
      title: "fait débat dans le staff",
      trigger: "analyse tactique",
      hook: "Le staff n'est pas d'accord sur son utilisation.",
      story: "Les choix tactiques autour de lui créent une fracture interne.",
      choices: [
        "Suivre la data",
        "Suivre ton instinct",
        "Tester en match",
        "Reporter la décision",
      ],
    },
    {
      type: "training",
      title: "remet en question son plan d’entraînement",
      trigger: "capacité d’adaptation",
      hook: "Certains membres du staff veulent changer son programme.",
      story:
        "Il devient le symbole d’une préparation qui doit rester cohérente.",
      choices: [
        "Changer le plan",
        "Maintenir la feuille",
        "Individualiser le suivi",
        "Impliquer le joueur",
      ],
    },
  ],
};

const PLAYER_EVENT_TEMPLATES = {
  Match: [
    {
      type: "player_performance",
      title: "doit réagir après son dernier match",
      trigger: "note de match",
      hook: "Le coach attend une réponse sur le terrain.",
      story: "Ta place dans le onze dépend de ta capacité à confirmer rapidement.",
      choices: [
        "Demander plus de temps de jeu",
        "Travailler en silence",
        "Parler au coach",
        "Répondre dans la presse",
      ],
    },
    {
      type: "coach_talk",
      title: "est convoqué par le coach",
      trigger: "gestion du rôle",
      hook: "Le coach veut clarifier ton statut dans le groupe.",
      story: "Cette discussion peut influencer ta titularisation dans les prochaines semaines.",
      choices: [
        "Accepter son plan",
        "Demander une place de titulaire",
        "Rester prudent",
        "Montrer de l’agacement",
      ],
    },
  ],

  Moral: [
    {
      type: "player_morale",
      title: "doute de sa progression",
      trigger: "confiance personnelle",
      hook: "Tu sens que ta carrière n’avance pas assez vite.",
      story: "Tu dois choisir entre patience, ambition et prise de risque.",
      choices: [
        "Demander un entretien",
        "Changer d’entraînement",
        "Forcer un départ",
        "Rester patient",
      ],
    },
  ],

  Mercato: [
    {
      type: "player_transfer",
      title: "reçoit un intérêt d’un autre club",
      trigger: "rumeur personnelle",
      hook: "Un club suit ton évolution et prépare peut-être une approche.",
      story: "Ton entourage pense que c’est peut-être le bon moment pour viser plus haut.",
      choices: [
        "Ouvrir la porte",
        "Rester fidèle",
        "Demander plus d’informations",
        "Mettre la pression au club",
      ],
    },
    {
      type: "star_message",
      title: "est mentionné par une star adverse",
      trigger: "séduction mercato",
      hook: "Une star d’un autre club parle de toi en interview.",
      story: "Ce message peut faire monter ta cote et attirer les médias.",
      choices: [
        "Répondre positivement",
        "Ignorer",
        "Flatter le club actuel",
        "Laisser planer le doute",
      ],
    },
  ],

  Médias: [
    {
      type: "player_media",
      title: "fait parler les médias",
      trigger: "pression individuelle",
      hook: "Les journalistes commencent à analyser ton avenir.",
      story: "Chaque phrase peut influencer ton image auprès du coach, des supporters et des recruteurs.",
      choices: [
        "Rester humble",
        "Afficher tes ambitions",
        "Éviter les médias",
        "Envoyer un message fort",
      ],
    },
  ],

  Blessures: [
    {
      type: "player_injury",
      title: "doit gérer une alerte physique",
      trigger: "fatigue personnelle",
      hook: "Le staff médical te conseille de ralentir.",
      story: "Tu peux préserver ton corps ou prendre le risque de jouer.",
      choices: [
        "Accepter le repos",
        "Demander à jouer",
        "Adapter l’entraînement",
        "Consulter le staff",
      ],
    },
  ],
};

function clamp(n, min = 0, max = 100) {
  return Math.max(min, Math.min(max, Math.round(Number(n) || 0)));
}

function uid(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function money(n) {
  return `${Number(n || 0).toLocaleString("fr-FR", { maximumFractionDigits: 1 })} M€`;
}

function getLastPlayedFixture(career) {
  return [...(career.fixtures || [])].reverse().find((fixture) => fixture.played) || null;
}

function getResultSentimentFromFixture(career, fixture) {
  if (!fixture || !fixture.score) return MEDIA_SENTIMENTS.NEUTRAL;

  const parsed = parseScore(fixture.score);
  if (!parsed) return MEDIA_SENTIMENTS.NEUTRAL;

  const isHome = fixture.home === career.club.name;
  const ownGoals = isHome ? parsed.homeGoals : parsed.awayGoals;
  const oppGoals = isHome ? parsed.awayGoals : parsed.homeGoals;

  if (ownGoals > oppGoals) return MEDIA_SENTIMENTS.POSITIVE;
  if (ownGoals < oppGoals) return MEDIA_SENTIMENTS.NEGATIVE;
  return MEDIA_SENTIMENTS.NEUTRAL;
}

function getSentimentTone(sentiment) {
  if (sentiment === MEDIA_SENTIMENTS.POSITIVE) return "lime";
  if (sentiment === MEDIA_SENTIMENTS.NEGATIVE) return "red";
  if (sentiment === MEDIA_SENTIMENTS.VIRAL) return "amber";
  return "cyan";
}

function getSentimentLabel(sentiment) {
  if (sentiment === MEDIA_SENTIMENTS.POSITIVE) return "Positif";
  if (sentiment === MEDIA_SENTIMENTS.NEGATIVE) return "Négatif";
  if (sentiment === MEDIA_SENTIMENTS.VIRAL) return "Viral";
  return "Neutre";
}

function createSocialPost(career, context = {}) {
  const fixture = context.fixture || getLastPlayedFixture(career);
  const sentiment = context.sentiment || getResultSentimentFromFixture(career, fixture);
  const author = pick(SOCIAL_AUTHORS);

  let text = pick(FAN_REACTIONS);

  if (fixture && fixture.score) {
    if (sentiment === MEDIA_SENTIMENTS.POSITIVE) {
      text = `${career.club.name} confirme sa progression après ${fixture.home} ${fixture.score} ${fixture.away}.`;
    } else if (sentiment === MEDIA_SENTIMENTS.NEGATIVE) {
      text = `Déception autour de ${career.club.name} après ${fixture.home} ${fixture.score} ${fixture.away}.`;
    } else {
      text = `${career.club.name} reste sous observation après ${fixture.home} ${fixture.score} ${fixture.away}.`;
    }
  }

  if (context.type === "transfer") {
    text = `Le mercato de ${career.club.name} fait beaucoup parler. Les supporters attendent une décision forte.`;
  }

  if (context.type === "injury") {
    text = `Le staff médical de ${career.club.name} est sous pression après une nouvelle alerte physique.`;
  }

  return {
    id: uid("social"),
    week: career.week,
    author,
    sentiment,
    text,
    likes: randomInt(80, sentiment === MEDIA_SENTIMENTS.VIRAL ? 8000 : 1800),
    replies: randomInt(4, sentiment === MEDIA_SENTIMENTS.VIRAL ? 700 : 160),
    topic: context.type || "general",
  };
}

function createWeeklySocialFeed(career, context = {}) {
  const basePosts = Array.from({ length: randomInt(3, 6) }, () =>
    createSocialPost(career, context),
  );

  const eventPosts = (career.events || []).slice(0, 2).map((event) => ({
    id: uid("social"),
    week: career.week,
    author: pick(SOCIAL_AUTHORS),
    sentiment:
      event.category === "Blessures" || event.category === "Direction"
        ? MEDIA_SENTIMENTS.NEGATIVE
        : event.category === "Supporters"
          ? MEDIA_SENTIMENTS.VIRAL
          : MEDIA_SENTIMENTS.NEUTRAL,
    text: `${event.category} : ${event.title}`,
    likes: randomInt(120, 2400),
    replies: randomInt(8, 240),
    topic: event.category,
  }));

  return [...eventPosts, ...basePosts];
}

function createPressConference(career, result, event, transferOffer) {
  const fixture = getLastPlayedFixture(career);
  const sentiment = getResultSentimentFromFixture(career, fixture);

  const questions = [];

  questions.push({
    id: uid("question"),
    type: PRESS_QUESTION_TYPES.RESULT,
    question:
      sentiment === MEDIA_SENTIMENTS.POSITIVE
        ? "Votre équipe semble en pleine confiance. Qu’est-ce qui a fait la différence ?"
        : sentiment === MEDIA_SENTIMENTS.NEGATIVE
          ? "Comment expliquez-vous ce résultat décevant ?"
          : "Quel regard portez-vous sur ce match équilibré ?",
    choices: [
      {
        label: "Valoriser le groupe",
        effects: { morale: 3, popularity: 1, pressure: -1 },
      },
      {
        label: "Rester exigeant",
        effects: { pressure: 2, development: 2, morale: -1 },
      },
      {
        label: "Protéger les joueurs",
        effects: { cohesion: 2, media: -1 },
      },
    ],
  });

  if (event?.player) {
    questions.push({
      id: uid("question"),
      type: PRESS_QUESTION_TYPES.PLAYER,
      question: `Un mot sur la situation de ${event.player} ?`,
      choices: [
        {
          label: "Le soutenir publiquement",
          effects: { morale: 2, cohesion: 1, media: 1 },
        },
        {
          label: "Mettre la pression",
          effects: { pressure: 2, development: 1, morale: -2 },
        },
        {
          label: "Éviter le sujet",
          effects: { media: -1, popularity: -1 },
        },
      ],
    });
  }

  if (transferOffer) {
    questions.push({
      id: uid("question"),
      type: PRESS_QUESTION_TYPES.TRANSFER,
      question: `Des informations circulent sur une approche de ${transferOffer.buyerClub}. Pouvez-vous confirmer ?`,
      choices: [
        {
          label: "Fermer la porte",
          effects: { transferTension: 2, boardTrust: 1 },
        },
        {
          label: "Rester ouvert",
          effects: { transferTension: 3, budget: 0 },
        },
        {
          label: "Protéger le joueur",
          effects: { morale: 1, media: -1 },
        },
      ],
    });
  }

  return {
    id: uid("press"),
    week: career.week,
    title: `Conférence de presse — Semaine ${career.week}`,
    fixture: fixture ? `${fixture.home} ${fixture.score || "-"} ${fixture.away}` : "Aucun match récent",
    sentiment,
    status: "pending",
    questions,
    answers: [],
  };
}

function applyMediaEffects(career, effects = {}) {
  return {
    ...career,
    morale: clamp(career.morale + (effects.morale || 0)),
    cohesion: clamp(career.cohesion + (effects.cohesion || 0)),
    popularity: clamp(career.popularity + (effects.popularity || 0)),
    pressure: clamp(career.pressure + (effects.pressure || 0)),
    media: clamp(career.media + (effects.media || 0)),
    development: clamp(career.development + (effects.development || 0)),
    boardTrust: clamp(career.boardTrust + (effects.boardTrust || 0)),
    transferTension: clamp(career.transferTension + (effects.transferTension || 0)),
    budget:
      effects.budget !== undefined
        ? Number((career.budget + effects.budget).toFixed(1))
        : career.budget,
  };
}

function getMediaBuzz(career) {
  const recentPosts = (career.socialFeed || []).slice(0, 12);
  const viralBonus = recentPosts.filter((post) => post.sentiment === MEDIA_SENTIMENTS.VIRAL).length * 8;
  const negativePenalty = recentPosts.filter((post) => post.sentiment === MEDIA_SENTIMENTS.NEGATIVE).length * 4;

  return clamp(
    (career.media || 50) +
      viralBonus +
      Math.round((career.popularity || 50) / 8) -
      negativePenalty,
    0,
    100,
  );
}

function randomInt(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

function maybeCreateInjuryReport(squad, week) {
  const availablePlayers = squad.filter((player) => !isPlayerInjured(player));

  if (!availablePlayers.length) return null;

  const riskyPlayers = [...availablePlayers]
    .sort((a, b) => b.fatigue - a.fatigue)
    .slice(0, 8);

  const target = pick(riskyPlayers);

  const fatigueRisk =
    target.fatigue > 75 ? 0.16 : target.fatigue > 60 ? 0.09 : 0.04;
  const randomRisk = Math.random();

  if (randomRisk > fatigueRisk) return null;

  const injury = createPlayerInjury(target, week);

  return {
    playerId: target.id,
    playerName: target.name,
    position: target.position,
    injury,
  };
}

function isPlayerInjured(player) {
  return Boolean(player.injury && player.injury.weeksRemaining > 0);
}

function isPlayerAvailable(player) {
  return !isPlayerInjured(player);
}

function createPlayerInjury(player, week) {
  const injuryType = pick(INJURY_TYPES);
  const duration = randomInt(injuryType.minWeeks, injuryType.maxWeeks);

  return {
    id: uid("injury"),
    label: injuryType.label,
    severity: injuryType.severity,
    weeksRemaining: duration,
    totalWeeks: duration,
    formPenalty: injuryType.formPenalty,
    startedWeek: week,
    playerId: player.id,
    playerName: player.name,
  };
}

function tickPlayerInjury(player) {
  if (!isPlayerInjured(player)) return player;

  const remaining = Math.max(0, player.injury.weeksRemaining - 1);

  if (remaining <= 0) {
    return {
      ...player,
      injury: null,
      fatigue: clamp(player.fatigue - 12),
      form: clamp(player.form - 2),
    };
  }

  return {
    ...player,
    injury: {
      ...player.injury,
      weeksRemaining: remaining,
    },
    fatigue: clamp(player.fatigue + 1),
    form: clamp(player.form - 1),
  };
}

function getLeaguePreset(league) {
  return LEAGUE_PRESETS[league] || LEAGUE_PRESETS["Ligue 1"];
}

function getTeamStrength(teamName, league = "Ligue 1", fallback = 58) {
  const preset = getLeaguePreset(league);
  const found = preset.find((team) => team.name === teamName);
  return found ? found.strength : fallback;
}

function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

function isTransferWindow(week) {
  return TRANSFER_WINDOWS.some(
    (window) => week >= window.startWeek && week <= window.endWeek,
  );
}

function getTransferWindowLabel(week) {
  const found = TRANSFER_WINDOWS.find(
    (window) => week >= window.startWeek && week <= window.endWeek,
  );

  return found ? found.label : "Hors mercato";
}

function getPlayerMarketValue(player) {
  const baseValue = Number(player.value || 1);
  const formMultiplier = 1 + (Number(player.form || 50) - 50) / 220;
  const ageMultiplier =
    player.age <= 21 ? 1.2 : player.age >= 32 ? 0.72 : 1;

  return Number((baseValue * formMultiplier * ageMultiplier).toFixed(1));
}

function getRecruitmentPool(career) {
  return career.budget <= 10 ? LOW_BUDGET_MARKET_POOL : MARKET_PLAYER_POOL;
}

function createMarketPlayer([name, position, age, overall, price], career) {
  return {
    id: uid("market"),
    name,
    position,
    age,
    overall,
    potential: clamp(overall + randomBetween(1, 8), overall, 94),
    price: Number(price),
    club: "Marché",
    scouted: false,
    shortlisted: false,
    wage: Number((price * randomBetween(0.035, 0.08)).toFixed(1)),
    fit:
      position === "BU" || position === "AD" || position === "AG"
        ? "Offensif"
        : position === "GB" || position === "DC"
          ? "Défensif"
          : "Équilibre",
  };
}

function createRecruitmentMarket(career) {
  const pool = getRecruitmentPool(career);

  return pool
    .map((player) => createMarketPlayer(player, career))
    .sort((a, b) => b.overall - a.overall);
}

function createAcademyProspect(career) {
  const archetype = pick(ACADEMY_ARCHETYPES);
  const overall = randomInt(archetype.minOverall, archetype.maxOverall);
  const potential = randomInt(
    Math.max(overall + 6, archetype.minPotential),
    archetype.maxPotential,
  );
  const country = pick(ACADEMY_COUNTRIES);
  const position = pick(archetype.positions);

  return {
    id: uid("academy"),
    name: `${pick(FIRST_NAMES)} ${pick(LAST_NAMES)}`,
    age: randomInt(15, 18),
    country,
    position,
    archetype: archetype.label,
    overall,
    potential,
    revealedPotential: false,
    weeksScouted: 0,
    scoutProgress: 0,
    promoted: false,
    signedWeek: null,
    estimatedValue: Number(((overall * potential) / 180).toFixed(1)),
  };
}

function createInitialAcademy(career) {
  return Array.from({ length: 5 }, () => createAcademyProspect(career));
}

function scoutAcademyProspects(career) {
  return (career.academy || []).map((prospect) => {
    if (prospect.promoted) return prospect;

    const scoutGain = randomInt(12, 26);
    const nextProgress = clamp(prospect.scoutProgress + scoutGain, 0, 100);

    return {
      ...prospect,
      weeksScouted: prospect.weeksScouted + 1,
      scoutProgress: nextProgress,
      revealedPotential: nextProgress >= 75,
    };
  });
}

function convertAcademyToPlayer(prospect, clubName) {
  const player = {
    id: uid("player"),
    name: prospect.name,
    age: prospect.age,
    position: prospect.position,
    overall: prospect.overall,
    potential: prospect.potential,
    value: Number(((prospect.overall * prospect.potential) / 150).toFixed(1)),
    morale: clamp(62 + randomBetween(-8, 12)),
    form: clamp(55 + randomBetween(-10, 12)),
    fatigue: clamp(randomBetween(5, 22)),
    goals: 0,
    appearances: 0,
    club: clubName,
    injury: null,
    injuryHistory: [],
    academyGraduate: true,
    transferListed: false,
  };

  return withContract(player, 10);
}

function progressPlayer(player) {
  if (isPlayerInjured(player)) {
    return {
      ...player,
      form: clamp(player.form - 1),
    };
  }

  const ageFactor =
    player.age <= 21
      ? 0.7
      : player.age <= 25
      ? 0.35
      : player.age <= 29
      ? 0.12
      : player.age >= 33
      ? -0.25
      : 0;

  const potentialGap = Math.max(0, Number(player.potential || player.overall) - player.overall);
  const formFactor = (player.form - 50) / 220;
  const moraleFactor = (player.morale - 50) / 260;
  const appearanceFactor = player.appearances > 0 ? 0.08 : 0;

  const growthChance =
    ageFactor + formFactor + moraleFactor + appearanceFactor + potentialGap / 180;

  if (growthChance > Math.random()) {
    return {
      ...player,
      overall: clamp(player.overall + 1, 40, player.potential || 99),
      value: Number((((player.overall + 1) * (player.overall + 1)) / 120).toFixed(1)),
    };
  }

  if (ageFactor < 0 && Math.random() < Math.abs(ageFactor) * 0.25) {
    return {
      ...player,
      overall: clamp(player.overall - 1, 35, 99),
      value: Number((((player.overall - 1) * (player.overall - 1)) / 120).toFixed(1)),
    };
  }

  return player;
}

function progressSquadWeekly(career) {
  return (career.squad || []).map(progressPlayer);
}

function createDefaultTactics(squad = []) {
  const bestByPosition = [...squad].sort((a, b) => b.overall - a.overall);
  const starters = bestByPosition.slice(0, 11).map((player) => player.id);

  return {
    formation: "4-3-3",
    mentality: "équilibré",
    pressing: 55,
    tempo: 55,
    starters,
  };
}

function getTacticalBonus(career) {
  const tactics = career.tactics || createDefaultTactics(career.squad);
  const starters = (career.squad || []).filter((player) =>
    (tactics.starters || []).includes(player.id),
  );

  if (!starters.length) return 0;

  const averageForm =
    starters.reduce((sum, player) => sum + player.form, 0) /
    Math.max(1, starters.length);

  const averageFatigue =
    starters.reduce((sum, player) => sum + player.fatigue, 0) /
    Math.max(1, starters.length);

  return clamp((averageForm - 50) * 0.08 - averageFatigue * 0.03, -5, 5);
}

function tickLoans(career) {
  const returningPlayers = [];

  const squad = (career.squad || []).map((player) => {
    if (!player.loanedOut || !player.loan) return player;

    const weeksRemaining = Math.max(0, Number(player.loan.weeksRemaining || 0) - 1);

    if (weeksRemaining <= 0) {
      returningPlayers.push(player.name);
      return {
        ...player,
        loanedOut: false,
        loan: null,
        morale: clamp(player.morale + 2),
        form: clamp(player.form + randomBetween(0, 4)),
        overall: clamp(player.overall + (Math.random() < 0.35 ? 1 : 0), 35, player.potential || 99),
      };
    }

    return {
      ...player,
      loan: {
        ...player.loan,
        weeksRemaining,
      },
    };
  });

  return {
    squad,
    returningPlayers,
  };
}

function isSeasonOver(career) {
  return (career.fixtures || []).every((fixture) => fixture.played);
}

function createSeasonSummary(career) {
  const position = getUserLeaguePosition(career);
  const topScorer = [...(career.squad || [])].sort((a, b) => b.goals - a.goals)[0];

  return {
    id: uid("season"),
    season: career.season,
    club: career.club.name,
    position,
    boardTrust: career.boardTrust,
    topScorer: topScorer ? topScorer.name : null,
    topScorerGoals: topScorer ? topScorer.goals : 0,
    completedWeek: career.week,
  };
}

function startNewSeason(career) {
  const nextSeason = career.season + 1;
  const renewedClub = { ...career.club };

  const squadWithContracts = (career.squad || [])
    .map(tickContractsAtSeasonTurn)
    .filter((player) => Number(player.contract?.yearsRemaining || 0) > 0);

  const fixtures = createRealFixtures(renewedClub.name, renewedClub.league);
  const leagueTable = createLeagueTable(renewedClub);

  return {
    ...career,
    season: nextSeason,
    week: 1,
    month: "Août",
    fixtures,
    leagueTable,
    squad: squadWithContracts.map((player) => ({
      ...player,
      appearances: 0,
      goals: 0,
      fatigue: clamp(player.fatigue - 20),
      form: clamp(player.form + randomBetween(-5, 8)),
    })),
    boardObjectives: evaluateBoardObjectives({
      ...career,
      season: nextSeason,
      week: 1,
      fixtures,
      leagueTable,
      squad: squadWithContracts,
      boardObjectives: createBoardObjectives(renewedClub),
    }),
    academy: scoutAcademyProspects(career),
    events: [],
    news: [
      {
        id: uid("news"),
        week: 1,
        type: "Direction",
        title: `Début de la saison ${nextSeason}`,
        body: "La direction fixe une nouvelle feuille de route pour la saison.",
      },
      ...(career.news || []),
    ],
  };
}

function normalizeCareer(career) {
  const club = career.club || CLUBS[0];
  const squad = (career.squad || []).map((player) =>
    withContract(
      {
        injury: null,
        injuryHistory: [],
        transferListed: false,
        ...player,
      },
      club.budget,
    ),
  );

  const leagueTable =
    career.leagueTable && career.leagueTable.length
      ? career.leagueTable
      : createLeagueTable(club);

  return {
    ...career,
    club,
    squad,
    fixtures:
      career.fixtures && career.fixtures.length
        ? career.fixtures
        : createRealFixtures(club.name, club.league),
    leagueTable,
    tactics: career.tactics || createDefaultTactics(squad),
    academy: career.academy || createInitialAcademy(career),
    academyLog: career.academyLog || [],
    transferOffers: career.transferOffers || [],
    transferHistory: career.transferHistory || [],
    recruitmentMarket:
      career.recruitmentMarket || createRecruitmentMarket(career),
    shortlist: career.shortlist || [],
    socialFeed: career.socialFeed || [],
    pressConferences: career.pressConferences || [],
    mediaReputation: career.mediaReputation ?? 50,
    mediaLog: career.mediaLog || [],
    boardObjectives:
      career.boardObjectives && career.boardObjectives.length
        ? evaluateBoardObjectives({
            ...career,
            club,
            squad,
            leagueTable,
          })
        : evaluateBoardObjectives({
            ...career,
            club,
            squad,
            leagueTable,
            boardObjectives: createBoardObjectives(club),
          }),
    contractsLog: career.contractsLog || [],
    seasonHistory: career.seasonHistory || [],
  };
}

function parseCsv(raw) {
  const rows = String(raw || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (rows.length < 2) return null;

  const headers = rows[0].split(/[,;\t]+/).map((header) => header.trim().toLowerCase());
  const data = rows.slice(1).map((row) => {
    const values = row.split(/[,;\t]+/).map((cell) => cell.trim());
    return headers.reduce((acc, key, index) => {
      acc[key] = values[index] || "";
      return acc;
    }, {});
  });

  return { data, headers };
}

function safeJsonParse(raw) {
  if (!raw || !raw.trim()) return null;

  try {
    return JSON.parse(raw);
  } catch {
    const parsedCsv = parseCsv(raw);
    if (!parsedCsv) return null;

    const { headers, data } = parsedCsv;
    const normalized = {};

    if (headers.includes("name") && headers.includes("club")) {
      normalized.squad = data.map((row) => ({
        name: row.name,
        age: row.age,
        position: row.position,
        overall: row.overall,
        potential: row.potential,
        value: row.value || row.wage,
        wage: row.wage,
        contractYears: row.contractyears || row.contract_years || 3,
        goals: row.goals,
        appearances: row.appearances,
      }));
    }

    if (headers.includes("week") && headers.includes("home") && headers.includes("away")) {
      normalized.fixtures = data.map((row) => ({
        week: row.week,
        home: row.home,
        away: row.away,
        score: row.score,
        cup: row.cup === "true" || row.cup === "1",
      }));
    }

    if (headers.includes("team") && headers.includes("points")) {
      normalized.leagueTable = data.map((row, index) => ({
        position: Number(row.position || index + 1),
        team: row.team,
        played: Number(row.played || row.p),
        won: Number(row.won || row.w),
        drawn: Number(row.drawn || row.d),
        lost: Number(row.lost || row.l),
        goalsFor: Number(row.goalsfor || row.gf || 0),
        goalsAgainst: Number(row.goalsagainst || row.ga || 0),
        goalDifference: Number(row.goaldifference || row.gd || 0),
        points: Number(row.points || row.pt || 0),
      }));
    }

    return normalized;
  }
}

function normalizeImportedName(rawName) {
  return String(rawName || "Inconnu")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\b([a-z])/g, (match) => match.toUpperCase());
}

function parseScore(scoreString) {
  const parts = String(scoreString || "").trim().split(/[\-:]/);
  if (parts.length !== 2) return null;
  const home = Number(parts[0]);
  const away = Number(parts[1]);
  if (Number.isNaN(home) || Number.isNaN(away)) return null;
  return { home, away };
}

function parseQuickResultsText(text) {
  return String(text || "")
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const match = line.match(/^(.+)\s+(\d+)[:\-](\d+)\s+(.+)$/);
      if (!match) return null;
      const [, home, homeScore, awayScore, away] = match;
      const scoreData = parseScore(`${homeScore}-${awayScore}`);
      if (!scoreData) return null;
      return {
        home: home.trim(),
        away: away.trim(),
        score: `${scoreData.home}-${scoreData.away}`,
        result:
          scoreData.home > scoreData.away
            ? "home"
            : scoreData.home < scoreData.away
            ? "away"
            : "draw",
      };
    })
    .filter(Boolean);
}

function createImportedPlayer(player, clubName) {
  return withContract(
    {
      id: uid("player"),
      name: normalizeImportedName(player.name),
      age: Number(player.age || 20),
      position: player.position || "MC",
      overall: clamp(Number(player.overall || 65)),
      potential: clamp(Number(player.potential || 70)),
      value: Number(player.value || player.wage || 0),
      morale: clamp(56 + randomBetween(-10, 18)),
      form: clamp(54 + randomBetween(-12, 12)),
      fatigue: clamp(randomBetween(6, 24)),
      goals: Number(player.goals || 0),
      appearances: Number(player.appearances || 0),
      club: clubName,
      signedWeek: 1,
      injury: null,
      injuryHistory: [],
      transferListed: false,
      contract: {
        wage: Number(player.wage || 0.4),
        yearsRemaining: Number(player.contractYears || 3),
        renewedAtWeek: 1,
      },
    },
    0,
  );
}

function createImportedFixtures(fixtures = [], clubName) {
  return fixtures
    .filter((fix) => fix && fix.home && fix.away)
    .map((fix) => ({
      id: uid("fixture"),
      week: Number(fix.week || 1),
      home: fix.home,
      away: fix.away,
      score: fix.score || "0-0",
      result: fix.score
        ? parseScore(fix.score)?.home > parseScore(fix.score)?.away
          ? "home"
          : parseScore(fix.score)?.home < parseScore(fix.score)?.away
          ? "away"
          : "draw"
        : "pending",
      cup: fix.cup || false,
      venue: fix.home === clubName ? "home" : "away",
    }))
    .sort((a, b) => a.week - b.week);
}

function createImportedLeagueTable(rows = [], clubName) {
  return (rows || [])
    .filter((row) => row && row.team)
    .map((row, index) => ({
      id: uid("table"),
      position: Number(row.position || index + 1),
      team: row.team,
      played: Number(row.played || 0),
      won: Number(row.won || 0),
      drawn: Number(row.drawn || 0),
      lost: Number(row.lost || 0),
      goalsFor: Number(row.goalsFor || row.gf || 0),
      goalsAgainst: Number(row.goalsAgainst || row.ga || 0),
      goalDifference: Number(row.goalDifference || row.gd || 0),
      points: Number(row.points || 0),
    }))
    .sort((a, b) => a.position - b.position);
}

function convertMarketPlayerToSquadPlayer(marketPlayer, clubName) {
  const player = {
    id: uid("player"),
    name: marketPlayer.name,
    age: marketPlayer.age,
    position: marketPlayer.position,
    overall: marketPlayer.overall,
    potential: marketPlayer.potential,
    value: Number(marketPlayer.price),
    morale: clamp(60 + randomBetween(-8, 14)),
    form: clamp(58 + randomBetween(-10, 18)),
    fatigue: clamp(randomBetween(5, 28)),
    goals: 0,
    appearances: 0,
    club: clubName,
    injury: null,
    injuryHistory: [],
  };

  return withContract(player, 10);
}

function refreshRecruitmentMarket(career) {
  return createRecruitmentMarket(career);
}

function createTransferOffer(career) {
  console.log("TRY TRANSFER OFFER", {
    week: career.week,
    window: getTransferWindowLabel(career.week),
    isWindow: isTransferWindow(career.week),
    squad: career.squad?.length,
  });

  if (!isTransferWindow(career.week)) return null;

  const squad = (career.squad || []).filter(
    (player) => !isPlayerInjured(player) && !player.loanedOut,
  );

  if (!squad.length) return null;

  const roll = Math.random();

  if (!FORCE_TRANSFER_OFFERS && roll > 0.42) return null;

  const candidates = [...squad]
    .sort((a, b) => {
      const scoreA = a.overall * 0.7 + a.form * 0.2 + (100 - a.age) * 0.1;
      const scoreB = b.overall * 0.7 + b.form * 0.2 + (100 - b.age) * 0.1;
      return scoreB - scoreA;
    })
    .slice(0, 10);

  const player = pick(candidates);
  const buyer = pick(BUYER_CLUBS);
  const marketValue = getPlayerMarketValue(player);
  const offerType = Math.random() < 0.82 ? "transfer" : "loan";

  const multiplier =
    offerType === "loan"
      ? randomBetween(0.08, 0.18)
      : randomBetween(0.85, 1.35);

  const amount = Number((marketValue * multiplier).toFixed(1));

  console.log("TRANSFER OFFER CREATED", {
    player: player.name,
    buyer: buyer.name,
    amount,
    type: offerType,
  });

  return {
    id: uid("offer"),
    week: career.week,
    window: getTransferWindowLabel(career.week),
    type: offerType,
    buyerClub: buyer.name,
    playerId: player.id,
    playerName: player.name,
    playerPosition: player.position,
    playerOverall: player.overall,
    playerAge: player.age,
    marketValue,
    amount,
    status: "pending",
    counterAmount: null,
    createdWeek: career.week,
  };
}

function formatOfferType(type) {
  return type === "loan" ? "Prêt" : "Transfert";
}

function poisson(lambda) {
  const safeLambda = Math.max(0.05, Math.min(3.2, lambda));
  const limit = Math.exp(-safeLambda);
  let k = 0;
  let p = 1;

  do {
    k += 1;
    p *= Math.random();
  } while (p > limit);

  return Math.min(5, k - 1);
}

function getCareerStrength(career) {
  const availableSquad = career.squad.filter(isPlayerAvailable);
  const squadForCalculation =
    availableSquad.length >= 11 ? availableSquad : career.squad;

  const averageOverall =
    squadForCalculation.reduce((sum, player) => sum + player.overall, 0) /
    Math.max(1, squadForCalculation.length);

  const averageFatigue =
    squadForCalculation.reduce((sum, player) => sum + player.fatigue, 0) /
    Math.max(1, squadForCalculation.length);

  const injuryPenalty = Math.max(0, 11 - availableSquad.length) * 1.5;

  return clamp(
    averageOverall * 0.55 +
      career.reputation * 0.25 +
      career.morale * 0.15 +
      career.cohesion * 0.12 +
      getTacticalBonus(career) -
      averageFatigue * 0.12 -
      injuryPenalty,
    35,
    92,
  );
}

function simulateMatchScore(homeStrength, awayStrength) {
  const diff = homeStrength - awayStrength;

  const homeExpected = Math.max(
    0.15,
    Math.min(2.9, 1.15 + diff / 55 + 0.18 + randomBetween(-0.25, 0.25)),
  );

  const awayExpected = Math.max(
    0.12,
    Math.min(2.7, 1.05 - diff / 65 + randomBetween(-0.25, 0.25)),
  );

  let homeGoals = poisson(homeExpected);
  let awayGoals = poisson(awayExpected);

  if (homeGoals + awayGoals >= 6 && Math.random() < 0.65) {
    if (homeGoals > awayGoals) homeGoals -= 1;
    else if (awayGoals > homeGoals) awayGoals -= 1;
    else homeGoals -= 1;
  }

  if (Math.random() < 0.12) {
    homeGoals = Math.min(homeGoals, 1);
    awayGoals = Math.min(awayGoals, 1);
  }

  return {
    homeGoals: Math.max(0, homeGoals),
    awayGoals: Math.max(0, awayGoals),
  };
}

function createPlayer(index, clubName, overrides = {}) {
  const overall = clamp(overrides.overall ?? 52 + Math.random() * 34, 45, 92);
  const player = {
    id: uid("player"),
    name: overrides.name || `${pick(FIRST_NAMES)} ${pick(LAST_NAMES)}`,
    age: overrides.age || clamp(17 + Math.random() * 18, 16, 39),
    position: overrides.position || pick(POSITIONS),
    overall,
    potential:
      overrides.potential ?? clamp(overall + Math.random() * 12, overall, 96),
    value: Number(((overall * overall) / 120).toFixed(1)),
    morale: clamp(50 + Math.random() * 35),
    form: clamp(45 + Math.random() * 45),
    fatigue: clamp(Math.random() * 55),
    injury: null,
    injuryHistory: [],
    goals: 0,
    appearances: 0,
    club: clubName,
  };

  return withContract(
    {
      ...player,
      ...overrides,
    },
    10,
  );
}

function createPresetPlayer([name, position, age, overall], clubName) {
  const player = {
    id: uid("player"),
    name,
    age,
    position,
    overall,
    potential: clamp(overall + randomBetween(2, 10), overall, 94),
    value: Number(((overall * overall) / 120).toFixed(1)),
    morale: clamp(58 + randomBetween(-10, 16)),
    form: clamp(55 + randomBetween(-12, 20)),
    fatigue: clamp(randomBetween(8, 38)),
    goals: 0,
    appearances: 0,
    club: clubName,
    injury: null,
    injuryHistory: [],
    transferListed: false,
  };

  return withContract(player, 10);
}

function createContractForPlayer(player, clubBudget = 10) {
  const baseWage = Math.max(
    0.1,
    Number(((player.overall * player.overall) / 9500).toFixed(1)),
  );

  const wage = Number(
    (baseWage * randomBetween(0.8, clubBudget > 50 ? 1.6 : 1.1)).toFixed(1),
  );

  const yearsRemaining = randomInt(1, 5);

  return {
    wage,
    yearsRemaining,
    status:
      yearsRemaining <= 1
        ? CONTRACT_STATUS.CRITICAL
        : yearsRemaining <= 2
          ? CONTRACT_STATUS.EXPIRING
          : CONTRACT_STATUS.SECURE,
    renewedAtWeek: null,
  };
}

function withContract(player, clubBudget = 10) {
  return {
    ...player,
    contract: player.contract || createContractForPlayer(player, clubBudget),
    transferListed: Boolean(player.transferListed),
  };
}

function updateContractStatus(player) {
  if (!player.contract) return player;

  const yearsRemaining = Number(player.contract.yearsRemaining || 0);

  return {
    ...player,
    contract: {
      ...player.contract,
      status:
        yearsRemaining <= 1
          ? CONTRACT_STATUS.CRITICAL
          : yearsRemaining <= 2
            ? CONTRACT_STATUS.EXPIRING
            : CONTRACT_STATUS.SECURE,
    },
  };
}

function tickContractsAtSeasonTurn(player) {
  if (!player.contract) return player;

  const yearsRemaining = Math.max(0, Number(player.contract.yearsRemaining || 0) - 1);

  return updateContractStatus({
    ...player,
    contract: {
      ...player.contract,
      yearsRemaining,
    },
  });
}

function getContractAlerts(career) {
  return (career.squad || []).filter(
    (player) =>
      player.contract &&
      player.contract.yearsRemaining <= 1 &&
      !player.loanedOut,
  );
}

function getTotalWageBill(career) {
  return Number(
    (career.squad || [])
      .reduce((sum, player) => sum + Number(player.contract?.wage || 0), 0)
      .toFixed(1),
  );
}

function createBoardObjectives(club) {
  const lowBudget = club.budget <= 10;
  const highReputation = club.reputation >= 85;

  return [
    {
      id: uid("objective"),
      type: BOARD_OBJECTIVE_TYPES.LEAGUE_POSITION,
      title: lowBudget ? "Se rapprocher du haut de tableau" : "Finir dans le Top 4",
      description: lowBudget
        ? "La direction veut une progression sportive visible cette saison."
        : "La direction attend une saison compétitive au classement.",
      target: lowBudget ? 8 : 4,
      progress: 0,
      status: "active",
      rewardTrust: 6,
      penaltyTrust: -6,
    },
    {
      id: uid("objective"),
      type: BOARD_OBJECTIVE_TYPES.MORALE,
      title: "Maintenir un vestiaire positif",
      description: "Garder le moral global au-dessus de 55.",
      target: 55,
      progress: 0,
      status: "active",
      rewardTrust: 4,
      penaltyTrust: -5,
    },
    {
      id: uid("objective"),
      type: BOARD_OBJECTIVE_TYPES.FINANCES,
      title: "Contrôler les finances",
      description: "Éviter de descendre sous un budget critique.",
      target: lowBudget ? 1 : Math.max(10, Math.round(club.budget * 0.12)),
      progress: 0,
      status: "active",
      rewardTrust: 4,
      penaltyTrust: -6,
    },
    {
      id: uid("objective"),
      type: BOARD_OBJECTIVE_TYPES.DEVELOPMENT,
      title: "Développer le projet sportif",
      description: "Augmenter le développement du club au fil de la saison.",
      target: highReputation ? 65 : 55,
      progress: 0,
      status: "active",
      rewardTrust: 5,
      penaltyTrust: -4,
    },
  ];
}

function getUserLeaguePosition(career) {
  const table = sortLeagueTable(
    career.leagueTable && career.leagueTable.length
      ? career.leagueTable
      : createLeagueTable(career.club),
  );

  const index = table.findIndex((team) => team.name === career.club.name);
  return index >= 0 ? index + 1 : null;
}

function evaluateBoardObjectives(career) {
  const position = getUserLeaguePosition(career);
  const totalWageBill = getTotalWageBill(career);

  return (career.boardObjectives || []).map((objective) => {
    let progress = objective.progress || 0;
    let status = objective.status || "active";

    if (objective.type === BOARD_OBJECTIVE_TYPES.LEAGUE_POSITION) {
      progress = position ? Math.max(0, objective.target - position + 1) : 0;
      status = position && position <= objective.target ? "on_track" : "at_risk";
    }

    if (objective.type === BOARD_OBJECTIVE_TYPES.MORALE) {
      progress = career.morale;
      status = career.morale >= objective.target ? "on_track" : "at_risk";
    }

    if (objective.type === BOARD_OBJECTIVE_TYPES.FINANCES) {
      progress = career.budget;
      status = career.budget >= objective.target ? "on_track" : "at_risk";
    }

    if (objective.type === BOARD_OBJECTIVE_TYPES.DEVELOPMENT) {
      progress = career.development;
      status = career.development >= objective.target ? "on_track" : "at_risk";
    }

    return {
      ...objective,
      progress,
      status,
      lastEvaluatedWeek: career.week,
      meta: {
        leaguePosition: position,
        wageBill: totalWageBill,
      },
    };
  });
}

function getObjectiveTone(status) {
  if (status === "on_track") return "lime";
  if (status === "at_risk") return "amber";
  if (status === "failed") return "red";
  if (status === "completed") return "green";
  return "cyan";
}

function getObjectiveLabel(status) {
  if (status === "on_track") return "Dans les temps";
  if (status === "at_risk") return "À risque";
  if (status === "failed") return "Échec";
  if (status === "completed") return "Réussi";
  return "Actif";
}

function createRealFixtures(clubName, league = "Ligue 1") {
  const preset = getLeaguePreset(league);

  const opponents = preset
    .filter((team) => team.name !== clubName)
    .map((team) => team.name);

  const selectedOpponents = opponents.slice(0, 12);
  console.log("REAL FIXTURES USED", clubName, league, selectedOpponents);
  return selectedOpponents.map((opponent, index) => ({
    id: uid("fixture"),
    week: index + 1,
    competition: index % 5 === 0 ? "Coupe" : "Championnat",
    home: index % 2 === 0 ? clubName : opponent,
    away: index % 2 === 0 ? opponent : clubName,
    played: false,
    score: null,
  }));
}

function createLeagueTable(club) {
  const preset = getLeaguePreset(club.league);

  const userTeam = {
    name: club.name,
    strength: clamp(club.reputation, 45, 94),
    user: true,
  };

  const teams = [
    userTeam,
    ...preset.filter((team) => team.name !== club.name),
  ].slice(0, 16);

  return teams.map((team) => ({
    name: team.name,
    strength: team.strength,
    user: Boolean(team.user),
    played: 0,
    wins: 0,
    draws: 0,
    losses: 0,
    gf: 0,
    ga: 0,
    gd: 0,
    points: 0,
    form: [],
  }));
}

function sortLeagueTable(table) {
  return [...table].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.gd !== a.gd) return b.gd - a.gd;
    if (b.gf !== a.gf) return b.gf - a.gf;
    return a.name.localeCompare(b.name);
  });
}

function applyTableResult(table, homeName, awayName, homeGoals, awayGoals) {
  return table.map((team) => {
    if (team.name !== homeName && team.name !== awayName) return team;

    const isHome = team.name === homeName;
    const gf = isHome ? homeGoals : awayGoals;
    const ga = isHome ? awayGoals : homeGoals;

    let points = 0;
    let result = "D";
    let wins = 0;
    let draws = 0;
    let losses = 0;

    if (gf > ga) {
      points = 3;
      result = "V";
      wins = 1;
    } else if (gf === ga) {
      points = 1;
      result = "N";
      draws = 1;
    } else {
      losses = 1;
    }

    return {
      ...team,
      played: team.played + 1,
      wins: team.wins + wins,
      draws: team.draws + draws,
      losses: team.losses + losses,
      gf: team.gf + gf,
      ga: team.ga + ga,
      gd: team.gd + gf - ga,
      points: team.points + points,
      form: [result, ...(team.form || [])].slice(0, 5),
    };
  });
}

function simulateLeagueWeek(table, userMatch) {
  let nextTable =
    table && table.length ? table.map((team) => ({ ...team })) : [];

  if (!nextTable.length) return nextTable;

  if (userMatch) {
    nextTable = applyTableResult(
      nextTable,
      userMatch.home,
      userMatch.away,
      userMatch.homeGoals,
      userMatch.awayGoals,
    );
  }

  const unavailable = new Set(
    userMatch ? [userMatch.home, userMatch.away] : [],
  );

  const availableTeams = nextTable
    .filter((team) => !unavailable.has(team.name))
    .map((team) => team.name)
    .sort(() => Math.random() - 0.5);

  for (let index = 0; index < availableTeams.length - 1; index += 2) {
    const home = availableTeams[index];
    const away = availableTeams[index + 1];

    const homeStrength =
      nextTable.find((team) => team.name === home)?.strength || 58;
    const awayStrength =
      nextTable.find((team) => team.name === away)?.strength || 58;

    const score = simulateMatchScore(homeStrength, awayStrength);

    nextTable = applyTableResult(
      nextTable,
      home,
      away,
      score.homeGoals,
      score.awayGoals,
    );
  }

  return sortLeagueTable(nextTable);
}
function createCareer(type = "manager", club = CLUBS[0], options = {}) {
  const squad = createSquadForClub(club);
  const leagueTable = createLeagueTable(club);

  return {
    id: uid("career"),
    type,
    managerName: options.managerName || "Coach",
    customObjective: options.objective || club.objectives,
    season: 1,
    week: 1,
    month: "Août",
    club: { ...club },
    squad,
    budget: club.budget,
    reputation: club.reputation,
    popularity: 55,
    boardTrust: 55,
    morale: 58,
    cohesion: 55,
    media: 50,
    pressure: 35,
    development: 50,
    transferTension: 20,
    transferOffers: [],
    transferHistory: [],
    recruitmentMarket: createRecruitmentMarket({ budget: club.budget }),
    shortlist: [],
    academy: createInitialAcademy({ club, budget: club.budget }),
    academyLog: [],
    contractsLog: [],
    socialFeed: [],
    pressConferences: [],
    mediaReputation: 50,
    mediaLog: [],
    tactics: createDefaultTactics(squad),
    seasonHistory: [],
    fixtures: createRealFixtures(club.name, club.league),
    leagueTable,
    boardObjectives: evaluateBoardObjectives({
      club,
      boardObjectives: createBoardObjectives(club),
      leagueTable,
      morale: 58,
      budget: club.budget,
      development: 50,
      week: 1,
    }),
    events: [],
    news: [],
    decisions: [],
    eventMemory: [],
    activeStorylines: [],
  };
}

function simulateResult(career) {
  const fixtures = career.fixtures.map((fixture) => ({ ...fixture }));
  const fixture = fixtures.find((item) => !item.played);

  if (!fixture) {
    return {
      fixtures,
      squad: career.squad,
      resultDelta: 0,
      summary: "Aucun match cette semaine",
      scorerName: null,
      matchRecord: null,
      injuryReport: null,
    };
  }

  const userStrength = getCareerStrength(career);
  const opponentName =
    fixture.home === career.club.name ? fixture.away : fixture.home;

  const opponentStrength = getTeamStrength(
    opponentName,
    career.club.league,
    58,
  );

  const isHome = fixture.home === career.club.name;

  const score = isHome
    ? simulateMatchScore(userStrength, opponentStrength)
    : simulateMatchScore(opponentStrength, userStrength);

  const ownGoals = isHome ? score.homeGoals : score.awayGoals;
  const oppGoals = isHome ? score.awayGoals : score.homeGoals;

  fixture.played = true;
  fixture.score = `${score.homeGoals}-${score.awayGoals}`;

  let squad = career.squad.map((player) => ({ ...player }));
  let scorerName = null;

  const availablePlayers = squad.filter(isPlayerAvailable);

  if (ownGoals > 0) {
    const attackers = availablePlayers.filter((player) =>
      ["BU", "AD", "AG", "MOC", "MC"].includes(player.position),
    );

    const scorer = pick(
      attackers.length
        ? attackers
        : availablePlayers.length
          ? availablePlayers
          : squad,
    );

    squad = squad.map((player) => {
      if (player.id !== scorer.id) return player;

      return {
        ...player,
        goals: player.goals + 1,
        appearances: player.appearances + 1,
        form: clamp(player.form + 3),
      };
    });

    scorerName = scorer.name;
  }

  squad = squad.map((player) => {
    if (isPlayerInjured(player)) {
      return {
        ...player,
        fatigue: clamp(player.fatigue - 6),
      };
    }

    return {
      ...player,
      appearances:
        Math.random() < 0.25 ? player.appearances + 1 : player.appearances,
      fatigue: clamp(player.fatigue + randomBetween(4, 13)),
      form: clamp(player.form + randomBetween(-3, 3)),
    };
  });

  const injuryReport = maybeCreateInjuryReport(squad, career.week);

  if (injuryReport) {
    squad = squad.map((player) => {
      if (player.id !== injuryReport.playerId) return player;

      return {
        ...player,
        injury: injuryReport.injury,
        form: clamp(player.form - injuryReport.injury.formPenalty),
        fatigue: clamp(player.fatigue - 15),
        injuryHistory: [
          {
            id: injuryReport.injury.id,
            label: injuryReport.injury.label,
            severity: injuryReport.injury.severity,
            totalWeeks: injuryReport.injury.totalWeeks,
            startedWeek: career.week,
          },
          ...(player.injuryHistory || []),
        ],
      };
    });
  }

  const resultDelta = ownGoals > oppGoals ? 1 : ownGoals === oppGoals ? 0 : -1;

  return {
    fixtures,
    squad,
    resultDelta,
    summary: `${fixture.home} ${fixture.score} ${fixture.away}`,
    scorerName,
    injuryReport,
    matchRecord: {
      home: fixture.home,
      away: fixture.away,
      homeGoals: score.homeGoals,
      awayGoals: score.awayGoals,
    },
  };
}

function chooseEventCategory(career, resultDelta) {
  const categories =
    career.type === "player"
      ? ["Match", "Moral", "Médias", "Mercato", "Blessures"]
      : [
          "Match",
          "Moral",
          "Vestiaire",
          "Médias",
          "Mercato",
          "Staff",
          "Supporters",
          "Direction",
        ];

  if (career.squad.some((player) => player.fatigue > 72)) {
    categories.push("Blessures");
  }

  if (career.type === "player") {
    if (resultDelta < 0) categories.push("Médias", "Moral");
    if (resultDelta > 0) categories.push("Match", "Mercato");
  } else {
    if (resultDelta < 0) categories.push("Direction", "Médias", "Moral");
    if (resultDelta > 0) categories.push("Supporters", "Match");
  }

  const recent = career.eventMemory || [];
  const filtered = categories.filter(
    (category) =>
      !recent.slice(0, 4).some((item) => item.category === category),
  );
  return pick(filtered.length ? filtered : categories);
}

function consequencesFor(category, resultDelta, career) {
  const sign = resultDelta > 0 ? 1 : resultDelta < 0 ? -1 : 0;
  const map = {
    Match: { morale: 4 * sign, reputation: 2 * sign, popularity: 2 * sign },
    Blessures: { morale: -3, pressure: 5, cohesion: -2 },
    Moral: { morale: career.morale < 50 ? 7 : -2, cohesion: 2 },
    Vestiaire: { cohesion: career.cohesion < 50 ? 7 : -3, morale: -1 },
    Médias: { media: 7, pressure: 3, reputation: sign },
    Supporters: { popularity: 6, pressure: resultDelta < 0 ? 4 : -1 },
    Direction: { boardTrust: resultDelta < 0 ? -4 : 3, pressure: 3 },
    Mercato: { transferTension: 8, morale: -2, reputation: 1 },
    Staff: { development: 5, cohesion: 1 },
  };
  return map[category] || { morale: 1 };
}

function getEventRarity(resultDelta) {
  const roll = Math.random() * 100;
  if (roll > 97) return "Légendaire";
  if (roll > 88) return "Épique";
  if (roll > 68 || resultDelta < 0) return "Rare";
  return "Commun";
}

function getMonthName(week) {
  return MONTHS[Math.floor((week - 1) / 4)] || "Mai";
}

function getThemeClass(theme) {
  return theme === "light" ? "light" : "";
}

function createSvgImage(category, title, playerName, clubName) {
  const meta = CATEGORY_META[category] || CATEGORY_META.Match;
  const safeTitle = String(title).replaceAll("<", "").replaceAll(">", "");
  const safePlayer = String(playerName).replaceAll("<", "").replaceAll(">", "");
  const safeClub = String(clubName).replaceAll("<", "").replaceAll(">", "");

  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="720" viewBox="0 0 1200 720">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0f172a"/>
      <stop offset="30%" stop-color="#0f172a"/>
      <stop offset="75%" stop-color="#0f172a" stop-opacity="0.75"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${meta.color}"/>
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0.18"/>
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="12" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>
  <rect width="1200" height="720" fill="url(#bg)" />
  <rect x="60" y="60" width="1080" height="600" rx="40" fill="rgba(255,255,255,0.05)" stroke="rgba(255,255,255,0.12)" stroke-width="2" />
  <rect x="80" y="520" width="1040" height="120" rx="30" fill="url(#accent)" opacity="0.85" filter="url(#glow)" />
  <text x="90" y="155" font-family="Inter, Arial, sans-serif" font-size="48" font-weight="900" fill="white">${safeClub}</text>
  <text x="90" y="235" font-family="Inter, Arial, sans-serif" font-size="54" font-weight="900" fill="white">${safeTitle}</text>
  <text x="90" y="320" font-family="Inter, Arial, sans-serif" font-size="32" fill="#d1d5db">Joueur concerné :</text>
  <text x="90" y="370" font-family="Inter, Arial, sans-serif" font-size="40" font-weight="700" fill="white">${safePlayer}</text>
  <text x="90" y="450" font-family="Inter, Arial, sans-serif" font-size="24" fill="#9ca3af">Événement premium généré par le Career Hub</text>
  <text x="90" y="640" font-family="Inter, Arial, sans-serif" font-size="26" fill="white">${meta.icon} ${category}</text>
</svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function createLiveEditorEffects(category, consequences, playerName) {
  const clubEffects = Object.entries(consequences || {}).map(([key, value]) => {
    const formatted = value > 0 ? `+${value}` : `${value}`;
    return `Club : ${key} ${formatted}`;
  });

  const playerEffects = {
    Match: [
      `Augmenter la forme de ${playerName}`,
      `Donner plus de temps de jeu à ${playerName}`,
    ],
    Blessures: [
      `Mettre ${playerName} au repos 1 match`,
      `Réduire son intensité d'entraînement`,
    ],
    Moral: [
      `Ajuster son rôle dans l'effectif`,
      `Changer son temps de jeu prévu`,
    ],
    Vestiaire: [
      `Modifier l'importance de ${playerName} dans l'effectif`,
      `Surveiller sa relation avec les cadres`,
    ],
    Médias: [
      `Augmenter la pression médiatique autour de ${playerName}`,
      `Modifier légèrement sa réputation`,
    ],
    Mercato: [
      `Ajouter ${playerName} à une shortlist transfert`,
      `Modifier son statut`,
    ],
    Supporters: [
      `Augmenter la popularité de ${playerName}`,
      `Créer une storyline supporters`,
    ],
    Direction: [
      `Noter ${playerName} comme dossier board`,
      `Demander un objectif sportif sur 3 matchs`,
    ],
    Staff: [
      `Changer le plan d'entraînement de ${playerName}`,
      `Tester ${playerName} à un nouveau poste`,
    ],
  };

  return [...clubEffects, ...(playerEffects[category] || [])];
}

function buildContextualEvent(career, result) {
  const category = result.injuryReport
    ? "Blessures"
    : chooseEventCategory(career, result.resultDelta);

  const templateSource =
    career.type === "player" ? PLAYER_EVENT_TEMPLATES : EVENT_TEMPLATES;

  const templates = templateSource[category] || templateSource.Match;
  const recent = career.eventMemory || [];
  const available = templates.filter(
    (template) =>
      !recent
        .slice(0, 4)
        .some(
          (item) =>
            item.category === category && item.templateTitle === template.title,
        ),
  );
  const template = pick(available.length ? available : templates);

  const injuredPlayer = result.injuryReport
    ? career.squad.find((player) => player.id === result.injuryReport.playerId)
    : null;

  const players = [...career.squad]
    .sort((a, b) => {
      const scoreA =
        a.overall + a.form * 0.35 - a.fatigue * 0.2 + a.morale * 0.15;
      const scoreB =
        b.overall + b.form * 0.35 - b.fatigue * 0.2 + b.morale * 0.15;
      return scoreB - scoreA;
    })
    .slice(0, 10);

  const player = injuredPlayer || pick(players.length ? players : career.squad);
  const fixtureText = result.summary || "semaine sans match officiel";
  const consequences = consequencesFor(category, result.resultDelta, career);
  const impact = Object.entries(consequences)
    .map(([key, value]) => `${key} ${value > 0 ? "+" : ""}${value}`)
    .join(" · ");
  const rarity = getEventRarity(result.resultDelta);
  const title = `${player.name} ${template.title} — ${career.club.name}`;

  let description = "";
  let detail = "";

  if (result.injuryReport) {
    description = `${result.injuryReport.playerName} est touché physiquement. Le staff médical confirme une blessure : ${result.injuryReport.injury.label}.`;
    detail = `Durée estimée : ${result.injuryReport.injury.weeksRemaining} semaine(s). Gravité : ${result.injuryReport.injury.severity}. Le joueur va perdre en forme et devra revenir progressivement. Contexte : ${fixtureText}.`;
  } else if (template.type === "direct") {
    description = `${player.name} veut une réponse claire sur son rôle, son temps de jeu et sa place dans le projet.`;
    detail = `${template.story || "La situation demande une décision rapide."} Contexte : ${fixtureText}. Profil : ${player.position}, OVR ${player.overall}, forme ${player.form}, moral ${player.morale}, fatigue ${player.fatigue}.`;
  } else if (template.type === "media" || template.type === "reputation") {
    description = `Une histoire autour de ${player.name} sort dans les médias. Le club doit réagir avant que la situation ne prenne trop d'ampleur.`;
    detail = `${template.hook} ${template.story || ""} Contexte : ${fixtureText}.`;
  } else if (template.type === "transfer" || template.type === "offer") {
    description = `${player.name} devient un vrai dossier mercato. Son avenir au club n'est plus totalement verrouillé.`;
    detail = `${template.hook} Valeur estimée : ${money(player.value)}. Poste : ${player.position}. OVR ${player.overall}. Contexte : ${fixtureText}.`;
  } else if (template.type === "medical" || template.type === "rehab") {
    description = `${player.name} est au centre d'une alerte physique. Le staff médical demande une décision prudente.`;
    detail = `${template.hook} Fatigue actuelle : ${player.fatigue}. Forme : ${player.form}. Contexte : ${fixtureText}.`;
  } else if (template.type === "fans" || template.type === "protest") {
    description = `${player.name} devient un sujet fort chez les supporters. La pression populaire influence désormais tes choix.`;
    detail = `${template.story || template.hook} Contexte : ${fixtureText}.`;
  } else if (template.type === "board" || template.type === "contract") {
    description = `${player.name} devient un dossier suivi par la direction. Le board veut une décision claire.`;
    detail = `${template.story || template.hook} Valeur : ${money(player.value)}. Contexte : ${fixtureText}.`;
  } else if (
    template.type === "staff" ||
    template.type === "training" ||
    template.type === "performance"
  ) {
    description = `${player.name} fait débat en interne. Le staff attend une décision sportive cohérente.`;
    detail = `${template.hook} ${template.story || ""} Profil : ${player.position}, OVR ${player.overall}, forme ${player.form}. Contexte : ${fixtureText}.`;
  } else {
    description = `${player.name} devient un sujet important de la semaine.`;
    detail = `${template.hook} ${template.story || ""} Contexte : ${fixtureText}.`;
  }

  return {
    id: uid("event"),
    title,
    category,
    rarity,
    week: career.week,
    fixture: fixtureText,
    player: player.name,
    playerContext: {
      id: player.id,
      name: player.name,
      position: player.position,
      overall: player.overall,
      form: player.form,
      morale: player.morale,
      fatigue: player.fatigue,
      value: player.value,
    },
    club: career.club,
    imageUrl: createSvgImage(category, title, player.name, career.club.name),
    description,
    detail,
    impact,
    consequences,
    liveEditorEffects: createLiveEditorEffects(
      category,
      consequences,
      player.name,
    ),
    status: "unread",
    choices: template.choices,
    templateTitle: template.title,
    eventType: template.type,
    injuryReport: result.injuryReport || null,
  };
}

function applyConsequences(career, event) {
  const next = { ...career };
  const cons = event.consequences || {};
  next.morale = clamp(next.morale + (cons.morale || 0));
  next.cohesion = clamp(next.cohesion + (cons.cohesion || 0));
  next.reputation = clamp(next.reputation + (cons.reputation || 0));
  next.popularity = clamp(next.popularity + (cons.popularity || 0));
  next.boardTrust = clamp(next.boardTrust + (cons.boardTrust || 0));
  next.media = clamp(next.media + (cons.media || 0));
  next.pressure = clamp(next.pressure + (cons.pressure || 0));
  next.development = clamp(next.development + (cons.development || 0));
  next.transferTension = clamp(
    next.transferTension + (cons.transferTension || 0),
  );
  return next;
}

function generateArticle(career, event) {
  return {
    id: uid("news"),
    week: career.week,
    type: event.category,
    title: event.title,
    body: `${event.description} Impact prévu : ${event.impact}.`,
  };
}

function ClubBadge({ club, size = "" }) {
  const initials = club.name
    .split(" ")
    .map((word) => word[0])
    .slice(0, 3)
    .join("");
  return (
    <div
      className={`badge ${size}`}
      style={{
        background: `linear-gradient(135deg, ${club.colors[0]}, ${club.colors[1]})`,
      }}
    >
      {initials}
    </div>
  );
}

function Kicker({ children, tone = "" }) {
  return <span className={`kicker ${tone}`}>{children}</span>;
}

function Stat({ label, value, tone = "" }) {
  return (
    <div className="stat">
      <div className="stat-label">{label}</div>
      <div className={`stat-value ${tone}`}>{value}</div>
    </div>
  );
}

function HomeScreen({ onChoose }) {
  return (
    <main className="hero">
      <section>
        <Kicker tone="lime">FC Career Hub</Kicker>
        <h1 className="hero-title">
          FIFA Career
          <br />
          <span className="gradient-text">Overhaul Mod</span>
        </h1>
        <p className="hero-subtitle">
          Un mode carrière premium pour FC26 : événements roleplay, vestiaire,
          médias, mercato, board, live editor et suivi de joueurs.
        </p>
        <div className="hero-actions">
          <button
            type="button"
            className="big-choice manager"
            onClick={() => onChoose("manager")}
          >
            <div className="stat-label">Kick-off</div>
            <h2>Manager Career</h2>
            <p>
              Contrôle le club, les décisions, la pression, les finances et les
              storylines.
            </p>
          </button>
          <button
            type="button"
            className="big-choice player"
            onClick={() => onChoose("player")}
          >
            <div className="stat-label">Player Path</div>
            <h2>Player Career</h2>
            <p>
              Suis un joueur, sa forme, son coach, sa réputation et ses choix.
            </p>
          </button>
        </div>
      </section>
    </main>
  );
}

function ClubPicker({ type, onBack, onConfirm }) {
  const [selectedName, setSelectedName] = useState(CLUBS[0].name);
  const [managerName, setManagerName] = useState(
    type === "player" ? "Mon Pro" : "Coach",
  );
  const [objective, setObjective] = useState(CLUBS[0].objectives);

  const selected = CLUBS.find((club) => club.name === selectedName) || CLUBS[0];

  function selectClub(club) {
    setSelectedName(club.name);
    setObjective(club.objectives);
  }

  return (
    <main className="club-picker">
      <div className="bg-grid" />
      <div className="club-picker-inner">
        <button type="button" className="secondary-btn" onClick={onBack}>
          ← Retour
        </button>
        <div
          className="club-row"
          style={{ marginTop: 30, justifyContent: "space-between" }}
        >
          <div>
            <Kicker tone="lime">Club Select</Kicker>
            <h1 className="title-xl">
              Créer une carrière {type === "player" ? "Joueur" : "Manager"}
            </h1>
            <p className="muted">Choisis un club, un nom et un objectif.</p>
          </div>
          <ClubBadge club={selected} size="large" />
        </div>
        <div className="grid-3" style={{ marginTop: 28 }}>
          {CLUBS.map((club) => (
            <button
              key={club.name}
              type="button"
              className={`club-card ${selected.name === club.name ? "selected" : ""}`}
              onClick={() => selectClub(club)}
            >
              <ClubBadge club={club} size="small" />
              <h2>{club.name}</h2>
              <p className="muted">{club.league}</p>
              <p>
                Budget <b>{money(club.budget)}</b> · Rép.{" "}
                <b>{club.reputation}</b>
              </p>
            </button>
          ))}
        </div>
        <div className="panel" style={{ marginTop: 22 }}>
          <div className="grid-2">
            <label>
              <div className="stat-label">
                {type === "player" ? "Nom du joueur" : "Nom du coach"}
              </div>
              <input
                className="input"
                value={managerName}
                onChange={(event) => setManagerName(event.target.value)}
              />
            </label>
            <label>
              <div className="stat-label">Objectif personnalisé</div>
              <input
                className="input"
                value={objective}
                onChange={(event) => setObjective(event.target.value)}
              />
            </label>
          </div>
          <button
            type="button"
            className="primary-btn"
            style={{ marginTop: 18 }}
            onClick={() =>
              onConfirm(type, selected, { managerName, objective })
            }
          >
            Commencer avec {selected.name}
          </button>
        </div>
      </div>
    </main>
  );
}

function MediaView({ career, onPressAnswer }) {
  const socialFeed = career.socialFeed || [];
  const conferences = career.pressConferences || [];
  const activeConference = conferences.find((conference) => conference.status === "pending");
  const buzz = getMediaBuzz(career);

  return (
    <div>
      <div className="club-row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <Kicker tone="amber">Médias</Kicker>
          <h2>Réseaux sociaux & presse</h2>
          <p className="muted">
            Gère l’image publique du club, les réactions supporters et les conférences.
          </p>
        </div>

        <div className="stat-grid">
          <Stat label="Buzz" value={buzz} tone="amber" />
          <Stat label="Popularité" value={career.popularity} tone="lime" />
          <Stat label="Pression" value={career.pressure} tone="red" />
        </div>
      </div>

      {activeConference ? (
        <div className="card" style={{ marginBottom: 22 }}>
          <Kicker tone={getSentimentTone(activeConference.sentiment)}>
            Conférence active
          </Kicker>
          <h2>{activeConference.title}</h2>
          <p className="muted">{activeConference.fixture}</p>

          <div className="grid-2" style={{ marginTop: 16 }}>
            {activeConference.questions.map((question) => {
              const alreadyAnswered = (activeConference.answers || []).some(
                (answer) => answer.questionId === question.id,
              );

              return (
                <div key={question.id} className="card" style={{ opacity: alreadyAnswered ? 0.55 : 1 }}>
                  <h3>{question.question}</h3>

                  {alreadyAnswered ? (
                    <p className="muted">Question déjà traitée.</p>
                  ) : (
                    <div className="choice-grid">
                      {question.choices.map((choice) => (
                        <button
                          key={choice.label}
                          type="button"
                          className="choice-btn"
                          onClick={() => onPressAnswer(activeConference.id, question.id, choice)}
                        >
                          {choice.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="card" style={{ marginBottom: 22 }}>
          <h3>Aucune conférence en attente</h3>
          <p className="muted">
            Les conférences apparaissent automatiquement après certaines semaines.
          </p>
        </div>
      )}

      <div className="grid-2">
        <div className="card">
          <h3>Fil social</h3>

          {socialFeed.length ? (
            socialFeed.slice(0, 18).map((post) => (
              <div key={post.id} className="card" style={{ marginTop: 12 }}>
                <div className="club-row" style={{ justifyContent: "space-between" }}>
                  <Kicker tone={getSentimentTone(post.sentiment)}>
                    {getSentimentLabel(post.sentiment)}
                  </Kicker>
                  <span className="muted">S{post.week}</span>
                </div>
                <h3>{post.author}</h3>
                <p>{post.text}</p>
                <p className="muted">
                  {post.likes} likes · {post.replies} réponses
                </p>
              </div>
            ))
          ) : (
            <p className="muted">Aucun post pour l’instant.</p>
          )}
        </div>

        <div className="card">
          <h3>Historique presse</h3>

          {conferences.length ? (
            conferences.map((conference) => (
              <div key={conference.id} className="fixture">
                <span>{conference.title}</span>
                <strong>
                  {conference.status === "resolved" ? "Terminée" : "En attente"}
                </strong>
              </div>
            ))
          ) : (
            <p className="muted">Aucune conférence enregistrée.</p>
          )}
        </div>
      </div>
    </div>
  );
}

function SettingsView() {
  return (
    <div className="card">
      <h2>Paramètres</h2>
      <p className="muted">Ajustez les paramètres du mode carrière et les options de personnalisation.</p>
    </div>
  );
}

function Dashboard({ career, onSeasonAdvance }) {
  const nextFixture =
    (career.fixtures || []).find((fixture) => fixture.result === "pending") ||
    (career.fixtures || [])[0] ||
    null;

  return (
    <div className="grid-2">
      <div className="card pitch" style={{ background: UI_GRADIENTS.panel }}>
        <div className="club-row" style={{ justifyContent: "space-between" }}>
          <div>
            <Kicker tone="lime">Central Hub</Kicker>
            <h2>Situaton actuelle</h2>
          </div>
          <Kicker tone="lime">Semaine {career.week}</Kicker>
        </div>
        <div className="stat-grid">
          <Stat label="Moral" value={career.morale} tone="lime" />
          <Stat label="Réputation" value={career.reputation} tone="cyan" />
          <Stat label="Buzz" value={getMediaBuzz(career)} tone="amber" />
          <Stat label="Pression" value={career.pressure} tone="amber" />
          <Stat label="Cohésion" value={career.cohesion} tone="violet" />
        </div>
        {nextFixture ? (
          <div className="card media" style={{ marginTop: 18, background: "rgba(255,255,255,0.04)" }}>
            <h3>Prochain match</h3>
            <p className="muted">Journée {nextFixture.week}</p>
            <p>
              <strong>{nextFixture.home}</strong> vs <strong>{nextFixture.away}</strong>
            </p>
          </div>
        ) : null}
      </div>
      <div className="card" style={{ background: UI_GRADIENTS.panel }}>
        <div className="club-row">
          <ClubBadge club={career.club} />
          <div>
            <h2>{career.club.name}</h2>
            <p className="muted">{career.club.league}</p>
          </div>
        </div>
        <div className="stat-grid" style={{ marginTop: 18 }}>
          <Stat label="Budget" value={money(career.budget)} tone="cyan" />
          <Stat label="Board" value={career.boardTrust} tone="violet" />
        </div>
        <p className="muted" style={{ marginTop: 18 }}>
          Objectif : <b className="soft">{career.customObjective}</b>
        </p>
        {isSeasonOver(career) ? (
          <button
            type="button"
            className="primary-btn"
            style={{ marginTop: 16 }}
            onClick={onSeasonAdvance}
          >
            Lancer la saison suivante
          </button>
        ) : null}
      </div>
    </div>
  );
}

function EventsView({ career, onOpen }) {
  const [filter, setFilter] = useState("all");
  const visibleEvents = useMemo(
    () =>
      career.events.filter((event) =>
        filter === "all" ? true : event.status === filter,
      ),
    [career.events, filter],
  );

  return (
    <div>
      <div
        className="club-row"
        style={{ justifyContent: "space-between", marginBottom: 16 }}
      >
        <h2>Inbox événements</h2>
        <div className="club-row">
          <button
            type="button"
            className={`secondary-btn ${filter === "all" ? "active" : ""}`}
            onClick={() => setFilter("all")}
          >
            Tous
          </button>
          <button
            type="button"
            className={`secondary-btn ${filter === "unread" ? "active" : ""}`}
            onClick={() => setFilter("unread")}
          >
            Nouveau
          </button>
          <button
            type="button"
            className={`secondary-btn ${filter === "resolved" ? "active" : ""}`}
            onClick={() => setFilter("resolved")}
          >
            Résolu
          </button>
        </div>
      </div>
      <div className="grid-3">
        {visibleEvents.length ? (
          visibleEvents.map((event) => {
            const meta = CATEGORY_META[event.category] || CATEGORY_META.Match;
            const resolved = event.status === "resolved";
            return (
              <button
                key={event.id}
                type="button"
                className="event-card"
                style={{ opacity: resolved ? 0.62 : 1 }}
                onClick={() => onOpen(event)}
              >
                <div
                  className="event-strip"
                  style={{ background: meta.color }}
                />
                <div className="event-body">
                  <div
                    className="club-row"
                    style={{ justifyContent: "space-between" }}
                  >
                    <Kicker>
                      {meta.icon} {event.category}
                    </Kicker>
                    <Kicker tone={resolved ? "green" : "amber"}>
                      {resolved ? "Résolu" : "Nouveau"}
                    </Kicker>
                  </div>
                  <h3>{event.title}</h3>
                  <p className="muted">{event.description}</p>
                  <p className="soft">{event.impact}</p>
                  {resolved && event.choice ? (
                    <p className="muted">
                      Choix effectué : <b>{event.choice}</b>
                    </p>
                  ) : null}
                </div>
              </button>
            );
          })
        ) : (
          <div className="card">Aucun événement dans ce filtre.</div>
        )}
      </div>
    </div>
  );
}

function EventModal({ event, onClose, onDecision }) {
  if (!event) return null;

  const meta = CATEGORY_META[event.category] || CATEGORY_META.Match;
  const playerName =
    event.playerContext?.name || event.player || "Joueur concerné";
  const playerPosition = event.playerContext?.position || "Poste inconnu";
  const playerOverall = event.playerContext?.overall || "?";
  const playerForm = event.playerContext?.form || "?";
  const playerMorale = event.playerContext?.morale || "?";
  const playerFatigue = event.playerContext?.fatigue || "?";

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal" style={{ background: UI_GRADIENTS.panel }}>
        <div className="event-strip" style={{ background: meta.color }} />
        <div className="modal-grid">
          <aside className="modal-left">
            <div
              style={{
                position: "relative",
                border: `2px solid ${meta.color}`,
                borderRadius: 24,
                overflow: "hidden",
                background: "rgba(15,23,42,0.95)",
              }}
            >
              <img
                className="event-image"
                src={event.imageUrl}
                alt={event.title}
              />
              <div
                style={{
                  position: "absolute",
                  left: 12,
                  top: 12,
                  padding: "8px 14px",
                  borderRadius: 999,
                  background: "rgba(15,23,42,0.88)",
                  color: "white",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  fontSize: 14,
                  fontWeight: 700,
                }}
              >
                <span>{meta.icon}</span>
                <strong>{event.category}</strong>
              </div>
            </div>
            <div className="stat-grid" style={{ marginTop: 18 }}>
              <Stat label="Rareté" value={event.rarity} tone="amber" />
              <Stat label="Semaine" value={event.week} tone="cyan" />
              <Stat label="Joueur" value={playerName} tone="lime" />
              <Stat label="OVR" value={playerOverall} tone="violet" />
            </div>
            <div className="card" style={{ marginTop: 18 }}>
              <h3>Profil joueur</h3>
              <p>
                Nom : <b>{playerName}</b>
              </p>
              <p>
                Poste : <b>{playerPosition}</b>
              </p>
              <p>
                OVR : <b>{playerOverall}</b>
              </p>
              <p>
                Forme : <b>{playerForm}</b>
              </p>
              <p>
                Moral : <b>{playerMorale}</b>
              </p>
              <p>
                Fatigue : <b>{playerFatigue}</b>
              </p>
            </div>
          </aside>
          <section className="modal-right">
            <div
              className="club-row"
              style={{ justifyContent: "space-between" }}
            >
              <div className="club-row">
                <Kicker>
                  {meta.icon} {event.category}
                </Kicker>
                <Kicker tone="amber">{event.rarity}</Kicker>
                <Kicker tone={event.status === "resolved" ? "green" : "red"}>
                  {event.status === "resolved" ? "Résolu" : "Décision requise"}
                </Kicker>
              </div>
              <button type="button" className="close-btn" onClick={onClose}>
                ×
              </button>
            </div>
            <h1>{event.title}</h1>
            <p className="soft">{event.description}</p>
            <div className="card media">
              <h3>Analyse roleplay</h3>
              <p className="muted">{event.detail}</p>
            </div>
            <div className="grid-2" style={{ marginTop: 14 }}>
              <div className="card pitch">
                <h3>Impact club</h3>
                <p>{event.impact}</p>
              </div>
              <div className="card media">
                <h3>Contexte match</h3>
                <p>{event.fixture}</p>
              </div>
            </div>
            {event.injuryReport ? (
              <div className="card" style={{ marginTop: 14 }}>
                <Kicker tone="red">Rapport médical</Kicker>
                <h3>{event.injuryReport.playerName}</h3>
                <p>
                  Blessure : <b>{event.injuryReport.injury.label}</b>
                </p>
                <p>
                  Gravité : <b>{event.injuryReport.injury.severity}</b>
                </p>
                <p>
                  Durée estimée : <b>{event.injuryReport.injury.weeksRemaining} semaine(s)</b>
                </p>
              </div>
            ) : null}
            {event.status === "resolved" ? (
              <div className="card" style={{ marginTop: 14 }}>
                <h3>Décision déjà prise</h3>
                <p className="muted">
                  Choix effectué : <b>{event.choice || "non précisé"}</b>
                </p>
              </div>
            ) : (
              <div className="card" style={{ marginTop: 14 }}>
                <h3>Décision narrative</h3>
                <div className="choice-grid">
                  {(event.choices || []).map((choice) => (
                    <button
                      key={choice}
                      type="button"
                      className="choice-btn"
                      onClick={() => onDecision(event, choice)}
                    >
                      {choice}
                      <br />
                      <small>Appliquer cette décision à la storyline.</small>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

function SquadView({ career }) {
  const [query, setQuery] = useState("");
  const squad = useMemo(() => {
    return career.squad
      .filter(
        (player) =>
          player.name.toLowerCase().includes(query.toLowerCase()) ||
          player.position.toLowerCase().includes(query.toLowerCase()),
      )
      .sort((a, b) => b.overall - a.overall);
  }, [career.squad, query]);

  return (
    <div>
      <input
        className="input"
        placeholder="Filtrer par nom ou poste"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
      />
      <div className="grid-3" style={{ marginTop: 18 }}>
        {squad.map((player) => (
          <div key={player.id} className="card">
            <div
              className="club-row"
              style={{ justifyContent: "space-between" }}
            >
              <h3>{player.name}</h3>
              <Kicker>{player.position}</Kicker>
            </div>
            <p className="muted">{player.age} ans</p>
            {player.injury && player.injury.weeksRemaining > 0 ? (
              <p className="red">
                🏥 {player.injury.label} — retour dans {player.injury.weeksRemaining} semaine(s)
              </p>
            ) : player.loanedOut ? (
              <p className="amber">
                Prêté à {player.loan?.club} — retour dans {player.loan?.weeksRemaining} semaine(s)
              </p>
            ) : (
              <p className="muted">Disponible</p>
            )}

            <div className="stat-grid">
              <Stat label="OVR" value={player.overall} tone="lime" />
              <Stat label="POT" value={player.potential} tone="cyan" />
              <Stat label="Forme" value={player.form} tone="amber" />
              <Stat label="Fatigue" value={player.fatigue} tone="red" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TacticsView({ career, onChange }) {
  const tactics = career.tactics || createDefaultTactics(career.squad);
  const sortedSquad = [...(career.squad || [])].sort((a, b) => b.overall - a.overall);
  const starters = sortedSquad.filter((player) =>
    (tactics.starters || []).includes(player.id),
  );

  function toggleStarter(player) {
    const current = tactics.starters || [];
    const exists = current.includes(player.id);

    const nextStarters = exists
      ? current.filter((id) => id !== player.id)
      : current.length < 11
      ? [...current, player.id]
      : current;

    onChange({ starters: nextStarters });
  }

  return (
    <div>
      <div className="club-row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <Kicker tone="lime">Tactique</Kicker>
          <h2>XI titulaire & style de jeu</h2>
        </div>
        <Stat label="Bonus tactique" value={getTacticalBonus(career)} tone="cyan" />
      </div>

      <div className="grid-2">
        <div className="card">
          <h3>Plan de jeu</h3>
          <label>
            <div className="stat-label">Formation</div>
            <select
              className="select"
              value={tactics.formation}
              onChange={(event) => onChange({ formation: event.target.value })}
            >
              <option value="4-3-3">4-3-3</option>
              <option value="4-2-3-1">4-2-3-1</option>
              <option value="3-5-2">3-5-2</option>
              <option value="4-4-2">4-4-2</option>
            </select>
          </label>

          <label>
            <div className="stat-label">Mentalité</div>
            <select
              className="select"
              value={tactics.mentality}
              onChange={(event) => onChange({ mentality: event.target.value })}
            >
              <option value="défensif">Défensif</option>
              <option value="équilibré">Équilibré</option>
              <option value="offensif">Offensif</option>
            </select>
          </label>

          <p className="muted" style={{ marginTop: 12 }}>
            Titulaires sélectionnés : <b>{(tactics.starters || []).length}/11</b>
          </p>
        </div>

        <div className="card">
          <h3>XI actuel</h3>
          {starters.length ? (
            starters.map((player) => (
              <div key={player.id} className="fixture">
                <span>{player.name} · {player.position}</span>
                <strong>OVR {player.overall}</strong>
              </div>
            ))
          ) : (
            <p className="muted">Aucun titulaire défini.</p>
          )}
        </div>
      </div>

      <div className="card" style={{ marginTop: 22 }}>
        <h3>Effectif disponible</h3>
        <div className="grid-3" style={{ marginTop: 16 }}>
          {sortedSquad.map((player) => {
            const selected = (tactics.starters || []).includes(player.id);

            return (
              <button
                key={player.id}
                type="button"
                className={`club-card ${selected ? "selected" : ""}`}
                onClick={() => toggleStarter(player)}
              >
                <h3>{player.name}</h3>
                <p className="muted">{player.position} · OVR {player.overall}</p>
                <p className="muted">Forme {player.form} · Fatigue {player.fatigue}</p>
                <Kicker tone={selected ? "lime" : "cyan"}>
                  {selected ? "Titulaire" : "Disponible"}
                </Kicker>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function AcademyView({ career, onAcademyAction }) {
  const prospects = career.academy || [];

  return (
    <div>
      <div className="club-row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <Kicker tone="lime">Académie</Kicker>
          <h2>Centre de formation</h2>
          <p className="muted">
            Détecte, observe et promeut les meilleurs jeunes talents.
          </p>
        </div>

        <button
          type="button"
          className="secondary-btn"
          onClick={() => onAcademyAction(null, "refresh-academy")}
        >
          Nouvelle détection
        </button>
      </div>

      <div className="grid-3">
        {prospects.length ? (
          prospects.map((prospect) => (
            <div key={prospect.id} className="card" style={{ opacity: prospect.promoted ? 0.55 : 1 }}>
              <div className="club-row" style={{ justifyContent: "space-between" }}>
                <h3>{prospect.name}</h3>
                <Kicker tone={prospect.revealedPotential ? "lime" : "amber"}>
                  {prospect.revealedPotential ? `POT ${prospect.potential}` : "Potentiel caché"}
                </Kicker>
              </div>

              <p className="muted">
                {prospect.country} · {prospect.position} · {prospect.age} ans
              </p>

              <p>OVR estimé : <b>{prospect.overall}</b></p>
              <p className="soft">Profil : {prospect.archetype}</p>
              <p className="muted">Scouting : {prospect.scoutProgress}%</p>

              {prospect.promoted ? (
                <p className="lime">Promu en équipe première</p>
              ) : (
                <button
                  type="button"
                  className="primary-btn"
                  onClick={() => onAcademyAction(prospect, "promote")}
                >
                  Promouvoir
                </button>
              )}
            </div>
          ))
        ) : (
          <div className="card">Aucun prospect observé.</div>
        )}
      </div>
    </div>
  );
}

function FC26ImportView({ career, onImportJson, onImportResults }) {
  const [rawJson, setRawJson] = useState("");
  const [quickResults, setQuickResults] = useState("");

  return (
    <div>
      <div className="club-row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <Kicker tone="cyan">Import FC26</Kicker>
          <h2>Importer des données réelles</h2>
          <p className="muted">
            Charge un fichier JSON/CSV ou colle des résultats rapides depuis FC26.
          </p>
        </div>
      </div>

      <div className="grid-2" style={{ gap: 22 }}>
        <div className="card">
          <h3>Importer JSON/CSV</h3>
          <p className="muted">Colle les données FC26 exportées depuis le jeu.</p>
          <textarea
            rows={10}
            value={rawJson}
            onChange={(event) => setRawJson(event.target.value)}
            placeholder="Colle ici le JSON ou le CSV de FC26..."
            style={{ width: "100%", fontFamily: "monospace" }}
          />
          <button
            type="button"
            className="primary-btn"
            onClick={() => onImportJson(rawJson)}
            style={{ marginTop: 14 }}
          >
            Importer les données
          </button>
        </div>

        <div className="card">
          <h3>Importer résultats rapides</h3>
          <p className="muted">Colle des lignes de scores FC26 pour mettre à jour le calendrier.</p>
          <textarea
            rows={10}
            value={quickResults}
            onChange={(event) => setQuickResults(event.target.value)}
            placeholder="Ex: PSG 2-1 OM"
            style={{ width: "100%", fontFamily: "monospace" }}
          />
          <button
            type="button"
            className="secondary-btn"
            onClick={() => onImportResults(quickResults)}
            style={{ marginTop: 14 }}
          >
            Appliquer les scores
          </button>
        </div>
      </div>

      <div className="card" style={{ marginTop: 20, background: UI_GRADIENTS.panel }}>
        <h3>Résumé</h3>
        <p className="muted">
          Votre club: <b>{career.club.name}</b> · Budget: <b>{money(career.budget)}</b>
        </p>
        <p className="muted">
          Joueurs FC26 importés: <b>{career.squad.length}</b> · Journée: <b>{career.week}</b>
        </p>
        <p className="muted">Les importations réelles sont prioritaires sur le calendrier et le classement.</p>
      </div>
    </div>
  );
}

function MercatoView({ career, onDecision, onRecruitmentAction }) {
  console.log("MERCATO VIEW ACTIVE", career.transferOffers);
  const offers = career.transferOffers || [];
  const pendingOffers = offers.filter((offer) => offer.status === "pending");
  const resolvedOffers = offers.filter((offer) => offer.status !== "pending");
  const market = career.recruitmentMarket || [];
  const shortlist = career.shortlist || [];

  return (
    <div>
      <div
        className="club-row"
        style={{ justifyContent: "space-between", marginBottom: 16 }}
      >
        <div>
          <h2>Mercato</h2>
          <p className="muted">
            Fenêtre actuelle : <b>{getTransferWindowLabel(career.week)}</b>
          </p>
          <p className="muted">
            Tension mercato : <b>{career.transferTension}</b>
          </p>
        </div>
        <button
          type="button"
          className="secondary-btn"
          onClick={() => onRecruitmentAction(null, "refresh-market")}
        >
          Actualiser le marché
        </button>
      </div>

      <div className="grid-2" style={{ gap: 18 }}>
        <div>
          <h3>Offres entrantes</h3>
          {pendingOffers.length ? (
            <div className="grid-3">
              {pendingOffers.map((offer) => (
                <div key={offer.id} className="card">
                  <div
                    className="club-row"
                    style={{ justifyContent: "space-between" }}
                  >
                    <div>
                      <h3>{offer.playerName}</h3>
                      <p className="muted">
                        {offer.type === "loan" ? "Prêt" : "Transfert"}
                      </p>
                    </div>
                    <Kicker tone="amber">{offer.buyerClub}</Kicker>
                  </div>
                  <p className="muted">Demande {money(offer.amount)}</p>
                  <div className="club-row" style={{ gap: 8, marginTop: 16 }}>
                    <button
                      type="button"
                      className="primary-btn"
                      onClick={() => onDecision(offer, "accept")}
                    >
                      Accepter
                    </button>
                    <button
                      type="button"
                      className="secondary-btn"
                      onClick={() => onDecision(offer, "reject")}
                    >
                      Refuser
                    </button>
                  </div>
                  <button
                    type="button"
                    className="secondary-btn"
                    style={{ marginTop: 10, width: "100%" }}
                    onClick={() => onDecision(offer, "counter")}
                  >
                    Contre-proposition
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="card">Aucune offre de transfert en attente.</div>
          )}
        </div>

        <div>
          <div className="club-row" style={{ justifyContent: "space-between", gap: 12 }}>
            <div>
              <h3>Recrutement</h3>
              <p className="muted">Marché actuel et shortlist de cibles.</p>
            </div>
            <span className="muted">
              Budget : <b>{money(career.budget)}</b>
            </span>
          </div>

          <div className="card" style={{ marginBottom: 16 }}>
            <h4>Shortlist</h4>
            {shortlist.length ? (
              shortlist.map((player) => (
                <div key={player.id} className="transfer-line">
                  <p>
                    {player.name} · {player.position} · OVR {player.overall}
                  </p>
                  <div className="club-row" style={{ gap: 8, marginTop: 8 }}>
                    <button
                      type="button"
                      className="secondary-btn"
                      onClick={() => onRecruitmentAction(player, "remove-shortlist")}
                    >
                      Retirer
                    </button>
                    <button
                      type="button"
                      className="primary-btn"
                      onClick={() => onRecruitmentAction(player, "buy")}
                    >
                      Acheter
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <p className="muted">Aucune cible en shortlist.</p>
            )}
          </div>

          <div className="grid-2" style={{ gap: 12 }}>
            {market.slice(0, 6).map((player) => (
              <div key={player.id} className="card">
                <div className="club-row" style={{ justifyContent: "space-between" }}>
                  <div>
                    <h3>{player.name}</h3>
                    <p className="muted">
                      {player.position} · {player.age} ans
                    </p>
                  </div>
                  <Kicker tone={player.shortlisted ? "lime" : "cyan"}>
                    {player.fit}
                  </Kicker>
                </div>
                <p className="muted">
                  OVR {player.overall} · POT {player.potential}
                </p>
                <p className="muted">
                  Salaire estimé {money(player.wage)} · Prix {money(player.price)}
                </p>
                <div className="club-row" style={{ gap: 8, marginTop: 12 }}>
                  <button
                    type="button"
                    className="secondary-btn"
                    onClick={() =>
                      onRecruitmentAction(
                        player,
                        player.shortlisted ? "remove-shortlist" : "shortlist",
                      )
                    }
                  >
                    {player.shortlisted ? "Retirer" : "Shortlister"}
                  </button>
                  <button
                    type="button"
                    className="primary-btn"
                    onClick={() => onRecruitmentAction(player, "buy")}
                  >
                    Acheter
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: 22 }}>
        <h3>Historique des transferts</h3>
        {resolvedOffers.length ? (
          resolvedOffers.map((offer) => (
            <div key={offer.id} className="transfer-line">
              <p>
                S{offer.resolvedWeek || career.week} · {offer.playerName} → {offer.buyerClub}
              </p>
              <p className="muted">
                {offer.status === "accepted"
                  ? `${offer.type === "loan" ? "Prêt" : "Vente"} pour ${money(offer.amount)}`
                  : offer.status === "rejected"
                  ? `Offre refusée à ${money(offer.amount)}`
                  : offer.status === "countered"
                  ? `Contre-proposition demandée à ${money(offer.counterAmount)}`
                  : `Statut : ${offer.status}`}
              </p>
            </div>
          ))
        ) : (
          <p className="muted">Aucun mouvement de mercato enregistré.</p>
        )}
      </div>
    </div>
  );
}

function CalendarView({ career }) {
  return (
    <div className="grid-2">
      {career.fixtures.map((fixture) => (
        <div key={fixture.id} className="card">
          <div className="fixture">
            <Kicker tone={fixture.played ? "green" : "cyan"}>
              Semaine {fixture.week}
            </Kicker>
            <span className="muted">{fixture.competition}</span>
          </div>
          <h3>
            {fixture.home} {fixture.score || "-"} {fixture.away}
          </h3>
        </div>
      ))}
    </div>
  );
}

function NewsView({ career }) {
  return (
    <div className="grid-2">
      {career.news.length ? (
        career.news.map((item) => (
          <div key={item.id} className="card">
            <Kicker>{item.type}</Kicker>
            <h3>{item.title}</h3>
            <p className="muted">{item.body}</p>
          </div>
        ))
      ) : (
        <div className="card">Aucune news pour l’instant.</div>
      )}
    </div>
  );
}

function HistoryView({ career }) {
  return (
    <div className="grid-2">
      <div className="card">
        <h2>Décisions</h2>
        {career.decisions.length ? (
          career.decisions.map((decision) => (
            <p key={decision.id}>
              S{decision.week} · {decision.event} → <b>{decision.choice}</b>
            </p>
          ))
        ) : (
          <p className="muted">Aucune décision.</p>
        )}
      </div>
      <div className="card">
        <h2>Storylines</h2>
        {career.activeStorylines.length ? (
          career.activeStorylines.map((story) => (
            <p key={story.id}>
              {story.title} · Dernier choix : <b>{story.lastChoice}</b>
            </p>
          ))
        ) : (
          <p className="muted">Aucune storyline active.</p>
        )}
      </div>
      <div className="card">
        <h2>Académie</h2>
        {career.academyLog && career.academyLog.length ? (
          career.academyLog.slice(0, 8).map((entry) => (
            <p key={entry.id}>
              S{entry.week} · {entry.label || entry.playerName || entry.action}
            </p>
          ))
        ) : (
          <p className="muted">Aucun journal d’académie.</p>
        )}
      </div>
      <div className="card">
        <h2>Médias</h2>
        {(career.mediaLog || []).length ? (
          career.mediaLog.map((item) => (
            <p key={item.id}>
              S{item.week} · {item.action} → <b>{item.label}</b>
            </p>
          ))
        ) : (
          <p className="muted">Aucune action média.</p>
        )}
      </div>
      <div className="card">
        <h2>Saisons</h2>
        {career.seasonHistory && career.seasonHistory.length ? (
          career.seasonHistory.slice(0, 8).map((entry) => (
            <p key={entry.id}>
              Saison {entry.season} · Position {entry.position} · Top scorer {entry.topScorer || "-"}
            </p>
          ))
        ) : (
          <p className="muted">Aucun résumé de saison.</p>
        )}
      </div>
      <div className="card">
        <h2>Mercato</h2>
        {career.transferHistory && career.transferHistory.length ? (
          career.transferHistory.slice(0, 8).map((entry) => (
            <p key={entry.id}>
              S{entry.week} · {entry.playerName} · {entry.action.replace("_", " ")}
            </p>
          ))
        ) : (
          <p className="muted">Aucun historique de mercato.</p>
        )}
      </div>
      <div className="card">
        <h2>Contrats</h2>
        {career.contractsLog && career.contractsLog.length ? (
          career.contractsLog.slice(0, 8).map((entry) => (
            <p key={entry.id}>
              S{entry.week} · {entry.playerName} · {entry.action.replace("_", " ")}
            </p>
          ))
        ) : (
          <p className="muted">Aucun historique de contrats.</p>
        )}
      </div>
    </div>
  );
}

function BoardView({ career, onContractAction }) {
  const contractAlerts = getContractAlerts(career);
  const wageBill = getTotalWageBill(career);

  return (
    <div className="grid-2" style={{ gap: 18 }}>
      <div className="card">
        <div className="club-row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <h2>Direction</h2>
            <p className="muted">Suivez les objectifs de la direction et gérez les contrats clés.</p>
          </div>
          <Kicker tone="cyan">Confiance {career.boardTrust}%</Kicker>
        </div>

        <div className="stat-grid">
          <Stat label="Budget" value={money(career.budget)} tone="lime" />
          <Stat label="Moral" value={career.morale} tone={career.morale >= 55 ? "lime" : "amber"} />
          <Stat label="Masse salariale" value={money(wageBill)} tone="amber" />
          <Stat label="Contrats urgents" value={contractAlerts.length} tone={contractAlerts.length ? "red" : "green"} />
        </div>

        <div style={{ marginTop: 20 }}>
          <h3>Objectifs de la direction</h3>
          {(career.boardObjectives || []).map((objective) => (
            <div key={objective.id} className="objective-row">
              <div>
                <h4>{objective.title}</h4>
                <p className="muted">{objective.description}</p>
              </div>
              <Kicker tone={getObjectiveTone(objective.status)}>
                {getObjectiveLabel(objective.status)}
              </Kicker>
            </div>
          ))}
        </div>
      </div>

      <div>
        <div className="card" style={{ marginBottom: 18 }}>
          <h3>Alertes contrats</h3>
          {contractAlerts.length ? (
            contractAlerts.map((player) => (
              <div key={player.id} className="transfer-line">
                <p>
                  {player.name} · {player.position} · {player.contract.yearsRemaining} an(s) restants
                </p>
                <div className="club-row" style={{ gap: 8, marginTop: 8 }}>
                  {player.contract.yearsRemaining <= 1 ? (
                    <>
                      <button
                        type="button"
                        className="primary-btn"
                        onClick={() => onContractAction(player, "renew")}
                      >
                        Renouveler
                      </button>
                      <button
                        type="button"
                        className="secondary-btn"
                        onClick={() => onContractAction(player, "release")}
                      >
                        Libérer
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      className="secondary-btn"
                      onClick={() => onContractAction(player, "transfer-list")}
                    >
                      Mettre sur liste
                    </button>
                  )}
                </div>
              </div>
            ))
          ) : (
            <p className="muted">Aucun contrat en situation d'alerte.</p>
          )}
        </div>

        <div className="card">
          <h3>Journal des contrats</h3>
          {career.contractsLog && career.contractsLog.length ? (
            career.contractsLog.slice(0, 8).map((entry) => (
              <div key={entry.id} className="transfer-line">
                <p>
                  S{entry.week} · {entry.playerName} · {entry.action.replace("_", " ")}
                </p>
                {entry.wage ? (
                  <p className="muted">Salaire {money(entry.wage)} · Prime {money(entry.signingFee)}</p>
                ) : null}
              </div>
            ))
          ) : (
            <p className="muted">Aucun historique de contrat disponible.</p>
          )}
        </div>
      </div>
    </div>
  );
}

function LeagueTableView({ career }) {
  const table = sortLeagueTable(
    career.leagueTable && career.leagueTable.length
      ? career.leagueTable
      : createLeagueTable(career.club),
  );

  return (
    <div className="card">
      <div
        className="club-row"
        style={{ justifyContent: "space-between", marginBottom: 18 }}
      >
        <div>
          <Kicker tone="cyan">Championnat</Kicker>
          <h2>Classement simulé</h2>
        </div>
        <span className="muted">Semaine {career.week}</span>
      </div>

      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr className="muted" style={{ textAlign: "left" }}>
              <th style={{ padding: 10 }}>#</th>
              <th style={{ padding: 10 }}>Club</th>
              <th style={{ padding: 10 }}>Pts</th>
              <th style={{ padding: 10 }}>J</th>
              <th style={{ padding: 10 }}>V</th>
              <th style={{ padding: 10 }}>N</th>
              <th style={{ padding: 10 }}>D</th>
              <th style={{ padding: 10 }}>BP</th>
              <th style={{ padding: 10 }}>BC</th>
              <th style={{ padding: 10 }}>Diff</th>
              <th style={{ padding: 10 }}>Forme</th>
            </tr>
          </thead>

          <tbody>
            {table.map((team, index) => {
              const isUser = team.name === career.club.name;

              return (
                <tr
                  key={team.name}
                  style={{
                    background: isUser
                      ? "rgba(190,242,100,.14)"
                      : "transparent",
                    borderTop: "1px solid var(--border)",
                  }}
                >
                  <td style={{ padding: 10, fontWeight: 900 }}>{index + 1}</td>
                  <td style={{ padding: 10, fontWeight: isUser ? 1000 : 700 }}>
                    {team.name}
                  </td>
                  <td style={{ padding: 10, fontWeight: 1000 }}>
                    {team.points}
                  </td>
                  <td style={{ padding: 10 }}>{team.played}</td>
                  <td style={{ padding: 10 }}>{team.wins}</td>
                  <td style={{ padding: 10 }}>{team.draws}</td>
                  <td style={{ padding: 10 }}>{team.losses}</td>
                  <td style={{ padding: 10 }}>{team.gf}</td>
                  <td style={{ padding: 10 }}>{team.ga}</td>
                  <td style={{ padding: 10 }}>{team.gd}</td>
                  <td style={{ padding: 10 }}>
                    {(team.form || []).length ? team.form.join(" ") : "-"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DeltaLine({ label, before, after }) {
  const delta = Number(after || 0) - Number(before || 0);
  const positive = delta > 0;
  const negative = delta < 0;
  return (
    <div className="fixture">
      <span>{label}</span>
      <strong className={positive ? "lime" : negative ? "red" : "muted"}>
        {before} → {after}{" "}
        {delta !== 0 ? `(${delta > 0 ? "+" : ""}${delta})` : "(=)"}
      </strong>
    </div>
  );
}

function WeekSummaryModal({ summary, onClose, onOpenEvent }) {
  if (!summary) return null;
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal" style={{ maxWidth: 860 }}>
        <div
          className="event-strip"
          style={{
            background: "linear-gradient(90deg, var(--lime), var(--cyan))",
          }}
        />
        <div style={{ padding: 28 }}>
          <Kicker tone="lime">Résumé de semaine</Kicker>
          <h1 style={{ marginTop: 14 }}>Semaine {summary.week}</h1>
          <div className="card pitch" style={{ marginTop: 16 }}>
            <h2>Résultat</h2>
            <p className="soft" style={{ fontSize: 22, fontWeight: 900 }}>
              {summary.result}
            </p>
            <p className="muted">
              Buteur notable : <b>{summary.scorerName || "aucun"}</b>
            </p>
            {summary.injuryReport ? (
              <div className="card" style={{ marginTop: 16 }}>
                <Kicker tone="red">Alerte médicale</Kicker>
                <h3>{summary.injuryReport.playerName} est blessé</h3>
                <p className="muted">
                  Blessure : <b>{summary.injuryReport.injury.label}</b>
                </p>
                <p className="muted">
                  Durée estimée : <b>{summary.injuryReport.injury.weeksRemaining} semaine(s)</b>
                </p>
                <p className="muted">
                  Gravité : <b>{summary.injuryReport.injury.severity}</b>
                </p>
              </div>
            ) : null}
          </div>
          <div className="grid-2" style={{ marginTop: 16 }}>
            <div className="card">
              <h3>Variations du club</h3>
              <DeltaLine
                label="Moral"
                before={summary.before.morale}
                after={summary.after.morale}
              />
              <DeltaLine
                label="Réputation"
                before={summary.before.reputation}
                after={summary.after.reputation}
              />
              <DeltaLine
                label="Popularité"
                before={summary.before.popularity}
                after={summary.after.popularity}
              />
              <DeltaLine
                label="Pression"
                before={summary.before.pressure}
                after={summary.after.pressure}
              />
              <DeltaLine
                label="Board"
                before={summary.before.boardTrust}
                after={summary.after.boardTrust}
              />
            </div>
            <div className="card media">
              <h3>Événement tiré</h3>
              <Kicker>{summary.eventCategory}</Kicker>
              <h2>{summary.eventTitle}</h2>
              <p className="muted">{summary.eventDescription}</p>
            </div>
          </div>
          <div className="card" style={{ marginTop: 16 }}>
            <h3>Article de presse</h3>
            <p className="muted">{summary.article}</p>
          </div>
          {summary.mediaBuzz !== undefined ? (
            <div className="card" style={{ marginTop: 16 }}>
              <Kicker tone="amber">Impact médias</Kicker>
              <h3>Buzz médiatique : {summary.mediaBuzz}</h3>
              <p className="muted">
                Les réseaux sociaux et la presse réagissent à la semaine du club.
              </p>
            </div>
          ) : null}
          <div
            className="club-row"
            style={{ marginTop: 18, justifyContent: "flex-end" }}
          >
            <button
              type="button"
              className="secondary-btn"
              onClick={onOpenEvent}
            >
              Voir l’événement
            </button>
            <button type="button" className="primary-btn" onClick={onClose}>
              Continuer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CareerApp() {
  const [theme, setTheme] = useState(DEFAULT_THEME);
  const [screen, setScreen] = useState(DEFAULT_SCREEN);
  const [pendingType, setPendingType] = useState(DEFAULT_TYPE);
  const [careers, setCareers] = useState(() => [
    createCareer(DEFAULT_TYPE, CLUBS[0]),
  ]);
  const [activeId, setActiveId] = useState("");
  const [tab, setTab] = useState(DEFAULT_TAB);
  const [activeEvent, setActiveEvent] = useState(null);
  const [weekSummary, setWeekSummary] = useState(null);
  const [loaded, setLoaded] = useState(false);

  const career = useMemo(
    () => careers.find((item) => item.id === activeId) || careers[0],
    [careers, activeId],
  );
  const tabs = useMemo(
    () => [
      ["dashboard", "Hub"],
      ["events", "Événements"],
      ["media", "Médias"],
      ["squad", "Effectif"],
      ["tactics", "Tactique"],
      ["calendar", "Calendrier"],
      ["table", "Classement"],
      ["mercato", "Mercato"],
      ["academy", "Académie"],
      ["board", "Direction"],
      ["news", "News"],
      ["history", "Historique"],
      ["settings", "Paramètres"],
      ["fc26", "Import FC26"],
    ],
    [],
  );
  const pendingEvents = useMemo(
    () => career.events.filter((event) => event.status === "unread").length,
    [career.events],
  );
  const pendingTransferOffers = useMemo(
    () =>
      (career.transferOffers || []).filter((offer) => offer.status === "pending")
        .length,
    [career.transferOffers],
  );
  const contractAlertCount = useMemo(
    () => getContractAlerts(career).length,
    [career],
  );
  const themeClass = useMemo(() => getThemeClass(theme), [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((current) => (current === "dark" ? "light" : "dark"));
  }, []);

  const selectCareer = useCallback((event) => {
    setActiveId(event.target.value);
  }, []);

  const replaceCareer = useCallback((nextCareer) => {
    setCareers((list) =>
      list.map((item) => (item.id === nextCareer.id ? nextCareer : item)),
    );
  }, []);

  const createNewCareer = useCallback((type, club, options) => {
    const next = createCareer(type, club, options);
    setCareers((list) => [next, ...list]);
    setActiveId(next.id);
    setScreen("career");
    setTab(DEFAULT_TAB);
  }, []);

  const advanceWeek = useCallback(() => {
    const before = {
      morale: career.morale,
      reputation: career.reputation,
      popularity: career.popularity,
      pressure: career.pressure,
      boardTrust: career.boardTrust,
    };

    let nextCareer = {
      ...career,
      squad: career.squad.map((player) => tickPlayerInjury({ ...player })),
      fixtures: career.fixtures.map((fixture) => ({ ...fixture })),
    };

    const loanTick = tickLoans(nextCareer);
    nextCareer.squad = loanTick.squad;
    if (loanTick.returningPlayers.length) {
      nextCareer.news = [
        {
          id: uid("news"),
          week: nextCareer.week,
          type: "Mercato",
          title: "Retour de prêt",
          body: `${loanTick.returningPlayers.join(", ")} revient/reviennent de prêt.`,
        },
        ...(nextCareer.news || []),
      ];
    }

    const result = simulateResult(nextCareer);

    nextCareer.fixtures = result.fixtures;
    nextCareer.squad = result.squad;
    nextCareer.squad = progressSquadWeekly(nextCareer);
    if (nextCareer.week % 4 === 0) {
      nextCareer.squad = nextCareer.squad.map(progressPlayer);
    }
    const baseTable =
      nextCareer.leagueTable && nextCareer.leagueTable.length
        ? nextCareer.leagueTable
        : createLeagueTable(nextCareer.club);

    nextCareer.leagueTable = simulateLeagueWeek(baseTable, result.matchRecord);
    nextCareer.week += 1;
    nextCareer.month = getMonthName(nextCareer.week);

    nextCareer.morale = clamp(nextCareer.morale + result.resultDelta * 5);
    nextCareer.reputation = clamp(
      nextCareer.reputation + result.resultDelta * 2,
    );
    nextCareer.popularity = clamp(
      nextCareer.popularity + result.resultDelta * 3,
    );

    const transferOffer = createTransferOffer(nextCareer);
    if (transferOffer) {
      nextCareer.transferOffers = [
        transferOffer,
        ...(nextCareer.transferOffers || []),
      ];

      nextCareer.news = [
        {
          id: uid("news"),
          week: nextCareer.week,
          type: "Mercato",
          title: `${transferOffer.buyerClub} approche ${transferOffer.playerName}`,
          body:
            transferOffer.type === "loan"
              ? `${transferOffer.buyerClub} propose un prêt pour ${transferOffer.playerName}.`
              : `${transferOffer.buyerClub} propose ${money(transferOffer.amount)} pour ${transferOffer.playerName}.`,
        },
        ...(nextCareer.news || []),
      ];
    }

    const event = buildContextualEvent(nextCareer, result);
    nextCareer = applyConsequences(nextCareer, event);
    const article = generateArticle(nextCareer, event);

    nextCareer.events = [event, ...nextCareer.events];
    nextCareer.eventMemory = [
      {
        id: event.id,
        category: event.category,
        templateTitle: event.templateTitle,
        player: event.player,
        week: event.week,
      },
      ...(nextCareer.eventMemory || []),
    ].slice(0, EVENT_MEMORY_LIMIT);
    nextCareer.news = [article, ...nextCareer.news];

    const mediaContext = {
      fixture: getLastPlayedFixture(nextCareer),
      type: event.category,
      sentiment: getResultSentimentFromFixture(nextCareer, getLastPlayedFixture(nextCareer)),
    };

    const socialPosts = createWeeklySocialFeed(nextCareer, mediaContext);
    const pressConference =
      Math.random() < 0.65
        ? createPressConference(nextCareer, result, event, transferOffer)
        : null;

    nextCareer.socialFeed = [
      ...socialPosts,
      ...(nextCareer.socialFeed || []),
    ].slice(0, 80);

    if (pressConference) {
      nextCareer.pressConferences = [
        pressConference,
        ...(nextCareer.pressConferences || []),
      ].slice(0, 20);
    }

    nextCareer.mediaReputation = getMediaBuzz(nextCareer);

    nextCareer.boardObjectives = evaluateBoardObjectives(nextCareer);
    const contractAlerts = getContractAlerts(nextCareer);

    if (contractAlerts.length) {
      nextCareer.news = [
        {
          id: uid("news"),
          week: nextCareer.week,
          type: "Direction",
          title: "Contrats à surveiller",
          body: `${contractAlerts.length} joueur(s) arrivent dans une zone contractuelle sensible.`,
        },
        ...nextCareer.news,
      ];
      nextCareer.boardTrust = clamp(
        nextCareer.boardTrust - Math.min(3, contractAlerts.length),
      );
      nextCareer.transferTension = clamp(
        nextCareer.transferTension + Math.min(4, contractAlerts.length),
      );
    }

    replaceCareer(nextCareer);
    setTab(transferOffer ? "mercato" : "events");
    setActiveEvent(null);

    setWeekSummary({
      week: nextCareer.week,
      result: result.summary,
      scorerName: result.scorerName,
      injuryReport: result.injuryReport,
      before,
      after: {
        morale: nextCareer.morale,
        reputation: nextCareer.reputation,
        popularity: nextCareer.popularity,
        pressure: nextCareer.pressure,
        boardTrust: nextCareer.boardTrust,
      },
      eventId: event.id,
      eventTitle: event.title,
      eventCategory: event.category,
      eventDescription: event.description,
      article: article.body,
      mediaBuzz: nextCareer.mediaReputation,
      pressConferenceId: pressConference?.id || null,
    });
  }, [career, replaceCareer]);

  const handleDecision = useCallback(
    (event, choice) => {
      if (!event || event.status === "resolved") {
        setActiveEvent(null);
        return;
      }

      setCareers((list) =>
        list.map((item) => {
          if (item.id !== activeId) return item;

          const updatedEvents = item.events.map((existingEvent) => {
            if (existingEvent.id !== event.id) return existingEvent;

            return {
              ...existingEvent,
              status: "resolved",
              choice,
              resolvedWeek: item.week,
            };
          });

          return {
            ...item,
            events: updatedEvents,
            decisions: [
              {
                id: uid("decision"),
                week: item.week,
                event: event.title,
                choice,
              },
              ...(item.decisions || []),
            ],
            activeStorylines: [
              {
                id: uid("story"),
                title: event.title,
                category: event.category,
                lastChoice: choice,
              },
              ...(item.activeStorylines || []),
            ].slice(0, 8),
          };
        }),
      );

      setActiveEvent(null);
    },
    [activeId],
  );

  const handleTransferDecision = useCallback(
    (offer, action) => {
      setCareers((list) =>
        list.map((item) => {
          if (item.id !== activeId) return item;

          const existingOffer = (item.transferOffers || []).find(
            (candidate) => candidate.id === offer.id,
          );

          if (!existingOffer || existingOffer.status !== "pending") return item;

          const player = item.squad.find(
            (candidate) => candidate.id === existingOffer.playerId,
          );

          if (!player) return item;

          if (action === "accept") {
            const isLoan = existingOffer.type === "loan";
            const loanDuration = randomInt(6, 16);
            return {
              ...item,
              budget: Number((item.budget + existingOffer.amount).toFixed(1)),
              morale: clamp(item.morale - (isLoan ? 1 : 4)),
              cohesion: clamp(item.cohesion - (isLoan ? 1 : 3)),
              transferTension: clamp(item.transferTension + 3),
              squad: isLoan
                ? item.squad.map((candidate) =>
                    candidate.id === player.id
                      ? {
                          ...candidate,
                          loanedOut: true,
                          loan: {
                            club: existingOffer.buyerClub,
                            startedWeek: item.week,
                            weeksRemaining: loanDuration,
                            originalWeeks: loanDuration,
                          },
                          morale: clamp(candidate.morale - 3),
                        }
                      : candidate,
                  )
                : item.squad.filter((candidate) => candidate.id !== player.id),
              transferOffers: (item.transferOffers || []).map((candidate) =>
                candidate.id === offer.id
                  ? { ...candidate, status: "accepted", resolvedWeek: item.week }
                  : candidate,
              ),
              transferHistory: [
                {
                  id: uid("transfer"),
                  week: item.week,
                  action: "accepted",
                  type: existingOffer.type,
                  playerName: existingOffer.playerName,
                  buyerClub: existingOffer.buyerClub,
                  amount: existingOffer.amount,
                },
                ...(item.transferHistory || []),
              ],
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Mercato",
                  title: `${existingOffer.playerName} rejoint ${existingOffer.buyerClub}`,
                  body:
                    existingOffer.type === "loan"
                      ? `${existingOffer.playerName} part en prêt à ${existingOffer.buyerClub}.`
                      : `${existingOffer.playerName} quitte le club pour ${money(existingOffer.amount)}.`,
                },
                ...(item.news || []),
              ],
            };
          }

          if (action === "reject") {
            return {
              ...item,
              morale: clamp(item.morale - 1),
              transferTension: clamp(item.transferTension + 4),
              squad: item.squad.map((candidate) =>
                candidate.id === player.id
                  ? { ...candidate, morale: clamp(candidate.morale - 4) }
                  : candidate,
              ),
              transferOffers: (item.transferOffers || []).map((candidate) =>
                candidate.id === offer.id
                  ? { ...candidate, status: "rejected", resolvedWeek: item.week }
                  : candidate,
              ),
              transferHistory: [
                {
                  id: uid("transfer"),
                  week: item.week,
                  action: "rejected",
                  type: existingOffer.type,
                  playerName: existingOffer.playerName,
                  buyerClub: existingOffer.buyerClub,
                  amount: existingOffer.amount,
                },
                ...(item.transferHistory || []),
              ],
            };
          }

          if (action === "counter") {
            const counterAmount = Number((existingOffer.amount * 1.22).toFixed(1));

            return {
              ...item,
              transferTension: clamp(item.transferTension + 2),
              transferOffers: (item.transferOffers || []).map((candidate) =>
                candidate.id === offer.id
                  ? {
                      ...candidate,
                      status: "countered",
                      counterAmount,
                      resolvedWeek: item.week,
                    }
                  : candidate,
              ),
              transferHistory: [
                {
                  id: uid("transfer"),
                  week: item.week,
                  action: "countered",
                  type: existingOffer.type,
                  playerName: existingOffer.playerName,
                  buyerClub: existingOffer.buyerClub,
                  amount: existingOffer.amount,
                  counterAmount,
                },
                ...(item.transferHistory || []),
              ],
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Mercato",
                  title: `Contre-proposition envoyée pour ${existingOffer.playerName}`,
                  body: `Le club demande désormais ${money(counterAmount)} à ${existingOffer.buyerClub}.`,
                },
                ...(item.news || []),
              ],
            };
          }

          return item;
        }),
      );
    },
    [activeId],
  );

  const handleRecruitmentAction = useCallback((marketPlayer, action) => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;

        const recruitmentMarket = item.recruitmentMarket || [];
        const shortlist = item.shortlist || [];

        if (action === "shortlist") {
          const alreadyShortlisted = shortlist.some(
            (candidate) => candidate.id === marketPlayer.id,
          );

          return {
            ...item,
            shortlist: alreadyShortlisted
              ? shortlist
              : [{ ...marketPlayer, shortlisted: true }, ...shortlist],
            recruitmentMarket: recruitmentMarket.map((candidate) =>
              candidate.id === marketPlayer.id
                ? { ...candidate, shortlisted: true }
                : candidate,
            ),
          };
        }

        if (action === "remove-shortlist") {
          return {
            ...item,
            shortlist: shortlist.filter(
              (candidate) => candidate.id !== marketPlayer.id,
            ),
            recruitmentMarket: recruitmentMarket.map((candidate) =>
              candidate.id === marketPlayer.id
                ? { ...candidate, shortlisted: false }
                : candidate,
            ),
          };
        }

        if (action === "buy") {
          const price = Number(marketPlayer.price || 0);

          if (item.type === "player") {
            return {
              ...item,
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Mercato",
                  title: `${marketPlayer.name} intéresse ton entourage`,
                  body: `Ce profil représente une piste de carrière ou un futur coéquipier potentiel.`,
                },
                ...(item.news || []),
              ],
            };
          }

          if (item.budget < price) {
            return {
              ...item,
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Mercato",
                  title: `Budget insuffisant pour ${marketPlayer.name}`,
                  body: `Le club ne peut pas financer une offre de ${money(price)} avec un budget disponible de ${money(item.budget)}.`,
                },
                ...(item.news || []),
              ],
            };
          }

          const newPlayer = convertMarketPlayerToSquadPlayer(
            marketPlayer,
            item.club.name,
          );

          return {
            ...item,
            budget: Number((item.budget - price).toFixed(1)),
            reputation: clamp(item.reputation + (marketPlayer.overall >= 82 ? 2 : 1)),
            popularity: clamp(item.popularity + (marketPlayer.overall >= 82 ? 2 : 0)),
            transferTension: clamp(item.transferTension + 2),
            squad: [newPlayer, ...(item.squad || [])],
            recruitmentMarket: recruitmentMarket.filter(
              (candidate) => candidate.id !== marketPlayer.id,
            ),
            shortlist: shortlist.filter(
              (candidate) => candidate.id !== marketPlayer.id,
            ),
            transferHistory: [
              {
                id: uid("transfer"),
                week: item.week,
                action: "signed",
                type: "incoming",
                playerName: marketPlayer.name,
                buyerClub: item.club.name,
                amount: price,
              },
              ...(item.transferHistory || []),
            ],
            news: [
              {
                id: uid("news"),
                week: item.week,
                type: "Mercato",
                title: `${marketPlayer.name} signe à ${item.club.name}`,
                body: `${item.club.name} officialise l’arrivée de ${marketPlayer.name} pour ${money(price)}.`,
              },
              ...(item.news || []),
            ],
          };
        }

        if (action === "refresh-market") {
          return {
            ...item,
            recruitmentMarket: refreshRecruitmentMarket(item),
            news: [
              {
                id: uid("news"),
                week: item.week,
                type: "Mercato",
                title: "Nouvelle liste de recrutement disponible",
                body: "Le staff a actualisé les profils observés sur le marché.",
              },
              ...(item.news || []),
            ],
          };
        }

        return item;
      }),
    );
  }, [activeId]);

  const handlePressAnswer = useCallback((conferenceId, questionId, choice) => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;

        const conference = (item.pressConferences || []).find(
          (candidate) => candidate.id === conferenceId,
        );

        if (!conference || conference.status === "resolved") return item;

        const question = conference.questions.find(
          (candidate) => candidate.id === questionId,
        );

        if (!question) return item;

        const nextCareer = applyMediaEffects(item, choice.effects || {});

        const updatedConferences = (nextCareer.pressConferences || []).map(
          (candidate) => {
            if (candidate.id !== conferenceId) return candidate;

            const answers = [
              ...(candidate.answers || []),
              {
                questionId,
                question: question.question,
                answer: choice.label,
                effects: choice.effects,
              },
            ];

            const resolved = answers.length >= candidate.questions.length;

            return {
              ...candidate,
              answers,
              status: resolved ? "resolved" : "pending",
            };
          },
        );

        return {
          ...nextCareer,
          pressConferences: updatedConferences,
          socialFeed: [
            {
              id: uid("social"),
              week: item.week,
              author: "Conférence de presse",
              sentiment: MEDIA_SENTIMENTS.VIRAL,
              text: `Réponse presse : ${choice.label}`,
              likes: randomInt(250, 3200),
              replies: randomInt(20, 400),
              topic: "press",
            },
            ...(nextCareer.socialFeed || []),
          ],
          mediaLog: [
            {
              id: uid("medialog"),
              week: item.week,
              action: "press_answer",
              label: choice.label,
              question: question.question,
            },
            ...(nextCareer.mediaLog || []),
          ],
        };
      }),
    );
  }, [activeId]);

  const handleAcademyAction = useCallback((prospect, action) => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;

        if (action === "refresh-academy") {
          const cost = item.budget <= 10 ? 0.3 : 1.2;

          if (item.budget < cost) {
            return {
              ...item,
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Académie",
                  title: "Budget insuffisant pour le scouting",
                  body: `Le club ne peut pas financer une nouvelle tournée de détection à ${money(cost)}.`,
                },
                ...(item.news || []),
              ],
            };
          }

          return {
            ...item,
            budget: Number((item.budget - cost).toFixed(1)),
            academy: createInitialAcademy(item),
            academyLog: [
              {
                id: uid("academylog"),
                week: item.week,
                action: "refresh",
                label: "Nouvelle génération de prospects",
              },
              ...(item.academyLog || []),
            ],
            news: [
              {
                id: uid("news"),
                week: item.week,
                type: "Académie",
                title: "Nouvelle génération observée",
                body: "Le centre de formation propose une nouvelle liste de jeunes prospects.",
              },
              ...(item.news || []),
            ],
          };
        }

        if (!prospect) return item;

        if (action === "promote") {
          const found = (item.academy || []).find(
            (candidate) => candidate.id === prospect.id,
          );
          if (!found || found.promoted) return item;

          if (found.age < 16) {
            return {
              ...item,
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Académie",
                  title: `${found.name} est encore trop jeune`,
                  body: "Le staff recommande d’attendre avant une promotion en équipe première.",
                },
                ...(item.news || []),
              ],
            };
          }

          const newPlayer = convertAcademyToPlayer(found, item.club.name);

          return {
            ...item,
            squad: [newPlayer, ...(item.squad || [])],
            development: clamp(item.development + 2),
            academy: (item.academy || []).map((candidate) =>
              candidate.id === found.id
                ? { ...candidate, promoted: true, signedWeek: item.week }
                : candidate,
            ),
            academyLog: [
              {
                id: uid("academylog"),
                week: item.week,
                action: "promoted",
                playerName: found.name,
                position: found.position,
                potential: found.potential,
              },
              ...(item.academyLog || []),
            ],
            news: [
              {
                id: uid("news"),
                week: item.week,
                type: "Académie",
                title: `${found.name} promu en équipe première`,
                body: `${found.name}, ${found.position}, rejoint l’effectif professionnel.`,
              },
              ...(item.news || []),
            ],
          };
        }

        return item;
      }),
    );
  }, [activeId]);

  const handleFC26Import = useCallback((rawData) => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;

        const imported = safeJsonParse(rawData);
        if (!imported) return item;

        const importedPlayers = (imported.squad || []).map((player) =>
          createImportedPlayer(player, item.club.name),
        );
        const importedFixtures = createImportedFixtures((imported.fixtures || []), item.club.name);
        const importedLeague = createImportedLeagueTable(imported.leagueTable || [], item.club.name);

        return {
          ...item,
          squad: [...importedPlayers, ...item.squad],
          fixtures: importedFixtures.length ? importedFixtures : item.fixtures,
          leagueTable: importedLeague.length ? importedLeague : item.leagueTable,
          news: [
            {
              id: uid("news"),
              week: item.week,
              type: "Import",
              title: "Import FC26 effectué",
              body: "Les données FC26 ont été intégrées au club, avec renforts et calendrier actualisés.",
            },
            ...(item.news || []),
          ],
        };
      }),
    );
  }, [activeId]);

  const handleQuickResultsImport = useCallback((text) => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;

        const results = parseQuickResultsText(text);
        if (!results.length) return item;

        const fixtures = item.fixtures.map((fixture) => {
          const match = results.find(
            (result) =>
              result.home === fixture.home && result.away === fixture.away,
          );
          if (!match) return fixture;
          return {
            ...fixture,
            score: match.score,
            result: match.result,
          };
        });

        return {
          ...item,
          fixtures,
          news: [
            {
              id: uid("news"),
              week: item.week,
              type: "Import",
              title: "Résultats rapides importés",
              body: "Les scores FC26 ont été appliqués aux rencontres du calendrier.",
            },
            ...(item.news || []),
          ],
        };
      }),
    );
  }, [activeId]);

  const handleTacticsChange = useCallback((nextTactics) => {
    setCareers((list) =>
      list.map((item) =>
        item.id === activeId
          ? {
              ...item,
              tactics: {
                ...(item.tactics || createDefaultTactics(item.squad)),
                ...nextTactics,
              },
            }
          : item,
      ),
    );
  }, [activeId]);

  const handleSeasonAdvance = useCallback(() => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;
        if (!isSeasonOver(item)) return item;

        const summary = createSeasonSummary(item);
        const next = startNewSeason(item);

        return {
          ...next,
          seasonHistory: [summary, ...(item.seasonHistory || [])],
        };
      }),
    );

    setTab("dashboard");
  }, [activeId]);

  const handleContractAction = useCallback((player, action) => {
    setCareers((list) =>
      list.map((item) => {
        if (item.id !== activeId) return item;

        const target = item.squad.find((candidate) => candidate.id === player.id);
        if (!target) return item;

        if (action === "renew") {
          const currentWage = Number(target.contract?.wage || 0.3);
          const newWage = Number((currentWage * randomBetween(1.08, 1.35)).toFixed(1));
          const signingFee = Number((newWage * randomBetween(0.8, 1.8)).toFixed(1));

          if (item.budget < signingFee) {
            return {
              ...item,
              news: [
                {
                  id: uid("news"),
                  week: item.week,
                  type: "Direction",
                  title: `Renouvellement bloqué pour ${target.name}`,
                  body: `Le club ne peut pas couvrir la prime estimée à ${money(signingFee)}.`,
                },
                ...(item.news || []),
              ],
            };
          }

          return {
            ...item,
            budget: Number((item.budget - signingFee).toFixed(1)),
            morale: clamp(item.morale + 1),
            boardTrust: clamp(item.boardTrust + 1),
            squad: item.squad.map((candidate) =>
              candidate.id === target.id
                ? updateContractStatus({
                    ...candidate,
                    morale: clamp(candidate.morale + 5),
                    contract: {
                      ...candidate.contract,
                      wage: newWage,
                      yearsRemaining: randomInt(3, 5),
                      renewedAtWeek: item.week,
                    },
                  })
                : candidate,
            ),
            contractsLog: [
              {
                id: uid("contract"),
                week: item.week,
                action: "renewed",
                playerName: target.name,
                wage: newWage,
                signingFee,
              },
              ...(item.contractsLog || []),
            ],
            news: [
              {
                id: uid("news"),
                week: item.week,
                type: "Direction",
                title: `${target.name} prolonge son contrat`,
                body: `${target.name} signe une prolongation avec un salaire estimé à ${money(newWage)}.`,
              },
              ...(item.news || []),
            ],
          };
        }

        if (action === "transfer-list") {
          return {
            ...item,
            transferTension: clamp(item.transferTension + 2),
            squad: item.squad.map((candidate) =>
              candidate.id === target.id
                ? {
                    ...candidate,
                    transferListed: true,
                    morale: clamp(candidate.morale - 5),
                  }
                : candidate,
            ),
            contractsLog: [
              {
                id: uid("contract"),
                week: item.week,
                action: "transfer_listed",
                playerName: target.name,
              },
              ...(item.contractsLog || []),
            ],
          };
        }

        if (action === "release" && Number(target.contract?.yearsRemaining || 0) <= 1) {
          return {
            ...item,
            morale: clamp(item.morale - 2),
            boardTrust: clamp(item.boardTrust - 1),
            squad: item.squad.filter((candidate) => candidate.id !== target.id),
            contractsLog: [
              {
                id: uid("contract"),
                week: item.week,
                action: "released",
                playerName: target.name,
              },
              ...(item.contractsLog || []),
            ],
            news: [
              {
                id: uid("news"),
                week: item.week,
                type: "Direction",
                title: `${target.name} quitte le club`,
                body: `${target.name} est libéré à l’approche de la fin de son contrat.`,
              },
              ...(item.news || []),
            ],
          };
        }

        return item;
      }),
    );
  }, [activeId]);

  const openWeekEvent = useCallback(() => {
    const found = career.events.find(
      (event) => event.id === weekSummary?.eventId,
    );
    if (found) {
      setActiveEvent(found);
    }
    setWeekSummary(null);
  }, [career.events, weekSummary]);

  function renderTabContent() {
    switch (tab) {
      case "events":
        return <EventsView career={career} onOpen={setActiveEvent} />;
      case "media":
        return <MediaView career={career} onPressAnswer={handlePressAnswer} />;
      case "squad":
        return <SquadView career={career} />;
      case "tactics":
        return <TacticsView career={career} onChange={handleTacticsChange} />;
      case "calendar":
        return <CalendarView career={career} />;
      case "table":
        return <LeagueTableView career={career} />;
      case "mercato":
        return (
          <MercatoView
            career={career}
            onDecision={handleTransferDecision}
            onRecruitmentAction={handleRecruitmentAction}
          />
        );
      case "academy":
        return <AcademyView career={career} onAcademyAction={handleAcademyAction} />;
      case "fc26":
        return (
          <FC26ImportView
            career={career}
            onImportJson={handleFC26Import}
            onImportResults={handleQuickResultsImport}
          />
        );
      case "board":
        return <BoardView career={career} onContractAction={handleContractAction} />;
      case "news":
        return <NewsView career={career} />;
      case "history":
        return <HistoryView career={career} />;
      case "settings":
        return <SettingsView />;
      default:
        return <Dashboard career={career} onSeasonAdvance={handleSeasonAdvance} />;
    }
  }

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = safeJsonParse(raw) || JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length) {
          setCareers(parsed.map(normalizeCareer));
          setActiveId(parsed[0].id);
        }
      } else {
        setActiveId(careers[0]?.id || "");
      }
    } catch {
      localStorage.removeItem(STORAGE_KEY);
      setActiveId(careers[0]?.id || "");
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (loaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(careers));
    }
  }, [careers, loaded]);

  if (!loaded) {
    return (
      <main className="app">
        <div className="hero">
          <h1>Chargement du Career Hub...</h1>
        </div>
      </main>
    );
  }

  if (screen === "home") {
    return (
      <div className={`app ${themeClass}`}>
        <div className="bg-grid" />
        <HomeScreen
          onChoose={(type) => {
            setPendingType(type);
            setScreen("create");
          }}
        />
      </div>
    );
  }

  if (screen === "create") {
    return (
      <div className={`app ${themeClass}`}>
        <ClubPicker
          type={pendingType}
          onBack={() => setScreen("home")}
          onConfirm={createNewCareer}
        />
      </div>
    );
  }

  return (
    <div className={`app ${themeClass}`}>
      <div className="bg-grid" />
      <div className="shell">
        <div className="layout">
          <aside className="sidebar panel">
            <div className="club-row">
              <ClubBadge club={career.club} />
              <div>
                <Kicker tone="cyan">Career OS</Kicker>
                <h2>{career.club.name}</h2>
              </div>
            </div>
            <p className="muted">
              Saison {career.season} · Semaine {career.week} · {career.month}
            </p>
            <select className="select" value={activeId} onChange={selectCareer}>
              {careers.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.club.name} — {item.type}
                </option>
              ))}
            </select>
            <button
              type="button"
              className="secondary-btn"
              onClick={() => setScreen("home")}
            >
              Accueil
            </button>
            <button
              type="button"
              className="secondary-btn"
              onClick={toggleTheme}
            >
              Mode {theme === "dark" ? "clair" : "sombre"}
            </button>
            <button
              type="button"
              className="secondary-btn"
              onClick={() => setTab("mercato")}
            >
              Mercato {pendingTransferOffers > 0 ? `(${pendingTransferOffers})` : ""}
            </button>
            <nav className="nav">
              {tabs.map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  className={tab === id ? "active" : ""}
                  onClick={() => setTab(id)}
                >
                  <span
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <span>{label}</span>
                    {id === "events" && pendingEvents > 0 ? (
                      <span
                        style={{
                          minWidth: 22,
                          height: 22,
                          borderRadius: 999,
                          display: "grid",
                          placeItems: "center",
                          background: "var(--red)",
                          color: "white",
                          fontSize: 12,
                          fontWeight: 1000,
                        }}
                      >
                        {pendingEvents}
                      </span>
                    ) : id === "mercato" && pendingTransferOffers > 0 ? (
                      <span
                        style={{
                          minWidth: 22,
                          height: 22,
                          borderRadius: 999,
                          display: "grid",
                          placeItems: "center",
                          background: "var(--amber)",
                          color: "white",
                          fontSize: 12,
                          fontWeight: 1000,
                        }}
                      >
                        {pendingTransferOffers}
                      </span>
                    ) : id === "board" && contractAlertCount > 0 ? (
                      <span
                        style={{
                          minWidth: 22,
                          height: 22,
                          borderRadius: 999,
                          display: "grid",
                          placeItems: "center",
                          background: "var(--red)",
                          color: "white",
                          fontSize: 12,
                          fontWeight: 1000,
                        }}
                      >
                        {contractAlertCount}
                      </span>
                    ) : null}
                  </span>
                </button>
              ))}
            </nav>
            <div style={{ marginTop: "auto", display: "grid", gap: 10 }}>
              <button
                type="button"
                className="primary-btn"
                onClick={advanceWeek}
              >
                ▶ Avancer d’une semaine
              </button>
            </div>
          </aside>
          <main className="main">
            <header className="panel header-grid">
              <div>
                <Kicker tone="lime">
                  {career.type === "player" ? "Mode Joueur" : "Mode Manager"}
                </Kicker>
                <Kicker tone="red">{BUILD_LABEL}</Kicker>
                <h1 className="title-xl">{career.club.name}</h1>
                <p className="muted">{career.customObjective}</p>
              </div>
              <div className="stat-grid">
                <Stat label="Budget" value={money(career.budget)} tone="cyan" />
                <Stat label="Moral" value={career.morale} tone="lime" />
                <Stat
                  label="Réputation"
                  value={career.reputation}
                  tone="cyan"
                />
                <Stat
                  label="Direction"
                  value={career.boardTrust}
                  tone="violet"
                />
              </div>
            </header>
            {renderTabContent()}
          </main>
        </div>
      </div>
      <EventModal
        event={activeEvent}
        onClose={() => setActiveEvent(null)}
        onDecision={handleDecision}
      />
      <WeekSummaryModal
        summary={weekSummary}
        onClose={() => setWeekSummary(null)}
        onOpenEvent={openWeekEvent}
      />
    </div>
  );
}
